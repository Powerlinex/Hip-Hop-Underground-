extends SceneTree
## xvfb-run godot --path . -s tools/pose_shots.gd -- psalm
func _initialize()->void: _run.call_deferred()
func _run()->void:
	var id:String=OS.get_cmdline_user_args()[0] if OS.get_cmdline_user_args().size()>0 else "psalm"
	var root3:=Node3D.new(); root.add_child(root3)
	var env:=WorldEnvironment.new(); var e:=Environment.new(); e.background_mode=Environment.BG_COLOR; e.background_color=Color(.25,.25,.3); e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR; e.ambient_light_color=Color(.6,.6,.6); env.environment=e; root3.add_child(env)
	var l:=DirectionalLight3D.new(); l.rotation_degrees=Vector3(-40,30,0); root3.add_child(l)
	var cam:=Camera3D.new(); cam.position=Vector3(0.9,1.0,1.9); cam.fov=60; root3.add_child(cam); cam.look_at(Vector3(0,.95,0))
	var model:Node3D=load("res://fighters/%s.glb"%id).instantiate(); root3.add_child(model)
	var ap:=AnimationPlayer.new(); ap.add_animation_library("",load("res://anim/fight_lib.res")); model.add_child(ap); ap.root_node=NodePath("..")
	var P:=[["Punch_Enter",.5],["Punch_Cross",.3],["Haymaker_R",.4],["Uppercut_R",.35],["Kick_Front",.35],["Roundhouse_R",.4],["Hip_Toss",.5],["Suplex",.6],["Spell_Simple_Shoot",.2],["Taunt",.5],["Chokeslam",.5],["Grab_Hold",.3]]
	var d:=ProjectSettings.globalize_path("res://").path_join("../hhu_godot_shots/poses"); DirAccess.make_dir_recursive_absolute(d)
	for p in P:
		if not ap.has_animation(p[0]): print("missing ",p[0], ap.get_animation_list().slice(0,20)); continue
		ap.play(p[0]); ap.seek(p[1],true); ap.pause()
		for i in 3: await process_frame
		await RenderingServer.frame_post_draw
		root.get_texture().get_image().save_png(d.path_join("%s_%s.png"%[id,p[0]]))
	print("POSES DONE"); quit()
