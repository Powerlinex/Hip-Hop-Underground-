extends SceneTree
# Converts anims.glb + fight.glb animations into one AnimationLibrary that targets
# the fighter scenes' Rig/Skeleton3D bones. Root-motion/root rotation tracks are stripped.
func _init():
	var ref=load("res://fighters/psalm.glb").instantiate()
	var sk:Skeleton3D=ref.find_child("Skeleton3D",true,false)
	var key={}
	for i in sk.get_bone_count():
		var b=sk.get_bone_name(i); key[b.replace(".","_")]=b; key[b]=b
	var lib=AnimationLibrary.new()
	var counts={}
	for f in ["res://fighters/anims.glb","res://fighters/fight.glb"]:
		var s=load(f).instantiate(); var ap:AnimationPlayer=s.find_child("AnimationPlayer",true,false)
		for n in ap.get_animation_list():
			var a:Animation=ap.get_animation(n); var na=Animation.new(); na.length=a.length
			var kept=0; var maxk=0
			for t in a.get_track_count():
				var p=String(a.track_get_path(t)); var bone=""
				if p.find(":")>=0: bone=p.split(":")[1]
				else: bone=p.get_file()
				if not key.has(bone): continue
				bone=key[bone]
				if bone=="root": continue
				var ty=a.track_get_type(t)
				if ty!=Animation.TYPE_POSITION_3D and ty!=Animation.TYPE_ROTATION_3D and ty!=Animation.TYPE_SCALE_3D: continue
				if ty==Animation.TYPE_POSITION_3D and bone!="DEF-hips": continue
				var nt=na.add_track(ty); na.track_set_path(nt,NodePath("Rig/Skeleton3D:"+bone))
				na.track_set_interpolation_type(nt,a.track_get_interpolation_type(t))
				var kc=a.track_get_key_count(t); maxk=max(maxk,kc)
				for k in kc: na.track_insert_key(nt,a.track_get_key_time(t,k),a.track_get_key_value(t,k))
				kept+=1
			var nm=String(n)
			if lib.has_animation(nm) and maxk<=2: continue
			if nm in ["Walk","Idle","Crouch_Idle","Jump","Dance","Held","Grab_Hold","Tumble","Launched","Crouch_Fwd","Sprint","Jog_Fwd"] or a.loop_mode!=Animation.LOOP_NONE: na.loop_mode=Animation.LOOP_LINEAR
			if lib.has_animation(nm): lib.remove_animation(nm)
			lib.add_animation(nm,na); counts[nm]=kept
		s.free()
	print("ANIMS ",lib.get_animation_list().size()," ",lib.get_animation_list())
	print("ERR ",ResourceSaver.save(lib,"res://anim/fight_lib.res"))
	ref.free(); quit()
