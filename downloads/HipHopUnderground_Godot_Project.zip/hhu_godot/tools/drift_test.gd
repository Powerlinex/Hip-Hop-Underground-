extends SceneTree
## godot --headless --path . -s tools/drift_test.gd : checks additive flinch layer doesn't accumulate on a static pose
var sk:Skeleton3D; var fl; var hb:int; var frames:=0; var r0:Quaternion; var mx:=0.0
func _initialize()->void:
	var m:Node3D=load("res://fighters/psalm.glb").instantiate(); root.add_child(m)
	sk=m.find_child("Skeleton3D",true,false)
	fl=load("res://scripts/flinch.gd").new(); sk.add_child(fl); fl.setup(sk)
	hb=sk.find_bone("DEF-hips")
	sk.skeleton_updated.connect(_su)
var upd:=0
func _su()->void:
	upd+=1
	var q:=sk.get_bone_global_pose(hb).basis.get_rotation_quaternion()
	if upd==5: r0=q
	if upd>5: mx=maxf(mx,r0.angle_to(q))
func _process(dt:float)->bool:
	fl.step(1.0/60.0); frames+=1
	if frames>=600:
		print("DRIFT hips max deg over 600 frames: ",rad_to_deg(mx)," updates ",upd); return true
	return false
