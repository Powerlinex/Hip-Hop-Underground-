extends SceneTree
## xvfb-run godot --path . -s tools/view_shots.gd -- psalm [tag] : 4 poses x 5 views contact frames
func _initialize()->void: _run.call_deferred()
func _run()->void:
	var a:=OS.get_cmdline_user_args(); var id:String=a[0]; var tag:String=a[1] if a.size()>1 else "cur"
	var root3:=Node3D.new(); root.add_child(root3)
	var env:=WorldEnvironment.new(); var e:=Environment.new(); e.background_mode=Environment.BG_COLOR; e.background_color=Color(.55,.75,.6); e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR; e.ambient_light_color=Color(.7,.7,.7); env.environment=e; root3.add_child(env)
	var l:=DirectionalLight3D.new(); l.rotation_degrees=Vector3(-40,30,0); root3.add_child(l)
	var cam:=Camera3D.new(); cam.fov=50; root3.add_child(cam)
	var model:Node3D=load("res://fighters/%s.glb"%id).instantiate(); root3.add_child(model)
	# mimic game material setup
	for m in model.find_children("*","MeshInstance3D",true,false):
		var mi:=m as MeshInstance3D
		for si in mi.mesh.get_surface_count():
			var sm:=mi.mesh.surface_get_material(si)
			var nm:StandardMaterial3D=(sm.duplicate() if sm is StandardMaterial3D else StandardMaterial3D.new())
			nm.vertex_color_use_as_albedo=nm.albedo_texture==null; nm.albedo_color=Color.WHITE
			mi.set_surface_override_material(si,nm)
	var ap:=AnimationPlayer.new(); ap.add_animation_library("",load("res://anim/fight_lib.res")); model.add_child(ap); ap.root_node=NodePath("..")
	var d:=ProjectSettings.globalize_path("res://").path_join("../hhu_godot_shots/views"); DirAccess.make_dir_recursive_absolute(d)
	var V:=[["front",Vector3(0,1.0,2.6)],["back",Vector3(0,1.0,-2.6)],["left",Vector3(2.6,1.0,0)],["right",Vector3(-2.6,1.0,0)],["top",Vector3(0.01,3.6,0.6)]]
	for p in [["A_TPose",0.0],["Punch_Enter",.5],["Kick_Front",.35],["Hip_Toss",.5]]:
		ap.play(p[0]); ap.seek(p[1],true); ap.pause()
		for v in V:
			cam.position=v[1]; cam.look_at(Vector3(0,0.95,0),Vector3.UP if v[0]!="top" else Vector3(0,0,-1))
			for i in 2: await process_frame
			await RenderingServer.frame_post_draw
			root.get_texture().get_image().save_png(d.path_join("%s_%s_%s_%s.png"%[tag,id,p[0],v[0]]))
	print("VIEWS DONE"); quit()
