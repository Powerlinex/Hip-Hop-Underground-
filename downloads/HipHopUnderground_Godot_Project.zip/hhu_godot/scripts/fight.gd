extends Node3D
## Fight scene: Neon Yard arena, 2 fighters, HUD, round flow, CPU AI, grabs/throws, Modes,
## juice (hitstop, shake, punch-in, particles, KO slow-mo) and story cutscenes.
const W:=960.0; const GROUND:=500.0; const WALL_L:=70.0; const WALL_R:=890.0; const PX:=0.0061
var F:Array[Fighter]=[]
var cam:Camera3D
var env:WorldEnvironment
var fx:FX
var hud:CanvasLayer
var hp_bars:Array=[]; var hype_bars:Array=[]; var name_l:Array=[]; var wins_l:Array=[]
var timer_l:Label; var msg_l:Label; var combo_l:Label; var sub_l:Label; var flash_r:ColorRect; var vign:ColorRect
var round_n:=1; var timer:=99; var tick:=0; var msg:=""; var msg_t:=0; var ko_t:=0; var winner:=-1
var hitstop:=0; var shake:=0.0; var cam_kick:=0.0; var slow:=0; var ko_cam:={}
var intro:={}   # mode intro camera
var phase:="fight"   # "cut", "fight", "over"
var cam_target:=Vector3(0,1.1,0)
var stats:={"hits":0,"blocks":0,"counters":0,"throws":0,"walls":0,"juggles":0,"strings":{},"modes":0,"specials":0,"flips":[0,0],"rounds":[]}
var cut:={}
var cut_panel:PanelContainer; var cut_name:Label; var cut_text:Label; var cut_pic:TextureRect
var specials:Array=[]
var anim_time:=0.0
var neon_mats:Array=[]
var shot_ko:=false; var shot_hit:=false
func _delayed_shot(n:String,d:float)->void:
	if d>0: await get_tree().create_timer(d,true,false,true).timeout
	Shots.shot(n)

func _ready()->void:
	_build_arena()
	fx=FX.new(); add_child(fx)
	_build_hud()
	var p:Array=Game.pick
	var rules:Dictionary=Game.rules
	if Game.story.get("on",false):
		var S:Dictionary=Game.SEASONS[Game.story.si]; var C:Dictionary=S.ch[Game.story.ch]
		var opp:String=Game.story.rival if C.opp=="RIVAL" else C.opp
		p=[Game.story.pi,Game.ri(opp)]; Game.pick=p; rules=C.get("rules",{}).duplicate()
		if Game.autotest=="story": rules["cpuHp"]=0.3
		Game.rules=rules
		sub_l.text=C.arena
	for i in 2:
		var f:=Fighter.new(); add_child(f); f.setup(Game.ROSTER[p[i]],i); F.append(f)
	_reset_fighters()
	if Game.story.get("on",false): _start_cut()
	else: _start_round()

# ======================= ARENA =======================
func _build_arena()->void:
	var hq:=Game.quality_high
	env=WorldEnvironment.new(); var e:=Environment.new()
	e.background_mode=Environment.BG_COLOR; e.background_color=Color("#07020f")
	e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR; e.ambient_light_color=Color("#3a2a5a"); e.ambient_light_energy=.6
	e.tonemap_mode=Environment.TONE_MAPPER_ACES; e.tonemap_exposure=1.0
	e.glow_enabled=true; e.glow_intensity=.9; e.glow_bloom=.08; e.glow_hdr_threshold=1.0
	e.fog_enabled=true; e.fog_light_color=Color("#1a0d2e"); e.fog_density=.02
	if hq:
		e.ssao_enabled=true; e.ssao_radius=1.2; e.ssao_intensity=2.0
		e.ssr_enabled=true; e.ssr_max_steps=48
	env.environment=e; add_child(env)
	cam=Camera3D.new(); cam.fov=38; cam.position=Vector3(0,1.45,6.4); add_child(cam); cam.current=true
	var key:=DirectionalLight3D.new(); key.rotation_degrees=Vector3(-50,25,0); key.light_energy=.55; key.light_color=Color("#d8c8ff"); key.shadow_enabled=true; add_child(key)
	var pl:=OmniLight3D.new(); pl.position=Vector3(-3.2,3,1.5); pl.light_color=Color("#b45cff"); pl.light_energy=4; pl.omni_range=9; add_child(pl)
	var gl:=OmniLight3D.new(); gl.position=Vector3(3.2,3,1.5); gl.light_color=Color("#33e07a"); gl.light_energy=4; gl.omni_range=9; add_child(gl)
	var front:=SpotLight3D.new(); front.position=Vector3(0,4,6); front.rotation_degrees=Vector3(-30,0,0); front.light_energy=3; front.spot_range=14; front.spot_angle=35; front.shadow_enabled=hq; add_child(front)
	# wet floor
	var fl:=MeshInstance3D.new(); var pm:=PlaneMesh.new(); pm.size=Vector2(24,12); fl.mesh=pm
	var fm:=StandardMaterial3D.new(); fm.albedo_color=Color("#120a1c"); fm.metallic=.35; fm.roughness=.12 if hq else .22; fm.metallic_specular=.9
	fl.material_override=fm; fl.position.z=-1; add_child(fl)
	# puddle/grid lines (emissive strips)
	for i in 7:
		_neon_box(Vector3(-6+i*2,0.005,-1),Vector3(.02,.005,10),Color("#5a2a8a"),.6)
	# backdrop art
	var bgq:=MeshInstance3D.new(); var qm:=QuadMesh.new(); qm.size=Vector2(26,11); bgq.mesh=qm
	var bm:=StandardMaterial3D.new(); bm.albedo_texture=load("res://art/bg.jpg"); bm.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED; bm.albedo_color=Color(.45,.4,.55)
	bgq.material_override=bm; bgq.position=Vector3(0,4.2,-7.5); add_child(bgq)
	# chain-link fence (procedural shader) + posts + neon tubes
	var fen:=MeshInstance3D.new(); var fq:=QuadMesh.new(); fq.size=Vector2(12,3.4); fen.mesh=fq; fen.position=Vector3(0,1.7,-2.2)
	var sh:=Shader.new(); sh.code="""shader_type spatial;render_mode unshaded,cull_disabled,blend_add;
uniform vec4 c1:source_color=vec4(.7,.4,1.,1.);uniform vec4 c2:source_color=vec4(.2,.9,.5,1.);
void fragment(){vec2 uv=UV*vec2(60.,17.);vec2 a=abs(fract(vec2(uv.x+uv.y,uv.x-uv.y)*.5)-.5);float l=smoothstep(.06,.0,min(a.x,a.y));
ALBEDO=mix(c1.rgb,c2.rgb,UV.x)*l*.55;ALPHA=l;}"""
	var smat:=ShaderMaterial.new(); smat.shader=sh; fen.material_override=smat; add_child(fen)
	for sx in [-1,1]:
		var side:=fen.duplicate(); side.position=Vector3(sx*6.2,1.7,-.6); side.rotation_degrees.y=-sx*65; add_child(side)
		_neon_box(Vector3(sx*3.1,1.8,-2.15),Vector3(.05,3.6,.05),Color("#b45cff") if sx<0 else Color("#33e07a"),5.0)
		_neon_box(Vector3(sx*4.6,3.3,-2.15),Vector3(3.0,.05,.05),Color("#e3b8ff") if sx<0 else Color("#7dffb0"),4.0)
		var spk:=MeshInstance3D.new(); var bx:=BoxMesh.new(); bx.size=Vector3(1.3,2.2,.9); spk.mesh=bx; spk.position=Vector3(sx*5.0,1.1,-3.2)
		var sm2:=StandardMaterial3D.new(); sm2.albedo_color=Color("#151018"); sm2.roughness=.6; spk.material_override=sm2; add_child(spk)
		for k in 2:
			var cone:=MeshInstance3D.new(); var cy:=CylinderMesh.new(); cy.top_radius=.42-k*.12; cy.bottom_radius=.42-k*.12; cy.height=.05; cone.mesh=cy
			cone.rotation_degrees.x=90; cone.position=Vector3(sx*5.0,1.55-k*.95,-2.74)
			var cm:=StandardMaterial3D.new(); cm.albedo_color=Color("#2a1f33"); cm.emission_enabled=true; cm.emission=Color("#b45cff") if sx<0 else Color("#33e07a"); cm.emission_energy_multiplier=.6; cone.material_override=cm; add_child(cone)
	# sign
	var sign:=Label3D.new(); sign.text="HIP HOP UNDERGROUND"; sign.font_size=120; sign.pixel_size=.006; sign.position=Vector3(0,3.15,-3.0)
	sign.modulate=Color(1.6,1.45,1.0); sign.outline_modulate=Color("#ff9a2a"); sign.outline_size=16; sign.shaded=false; add_child(sign)
	# crowd silhouettes
	var rng:=RandomNumberGenerator.new(); rng.seed=7
	var crowd_mm:=MultiMeshInstance3D.new(); var mm:=MultiMesh.new(); mm.transform_format=MultiMesh.TRANSFORM_3D; var cap:=CapsuleMesh.new(); cap.radius=.22; cap.height=1.3
	var cmat:=StandardMaterial3D.new(); cmat.albedo_color=Color("#0b0612"); cmat.roughness=1; cap.material=cmat
	mm.mesh=cap; mm.instance_count=70
	for i in 70: mm.set_instance_transform(i,Transform3D(Basis().scaled(Vector3(1,rng.randf_range(.85,1.2),1)),Vector3(rng.randf_range(-9,9),.6,rng.randf_range(-5.5,-3.0))))
	crowd_mm.multimesh=mm; add_child(crowd_mm)
	FX.rain(self,2400 if hq else 900)

func _neon_box(p:Vector3,s:Vector3,c:Color,energy:float)->void:
	var m:=MeshInstance3D.new(); var b:=BoxMesh.new(); b.size=s; m.mesh=b; m.position=p
	var mat:=StandardMaterial3D.new(); mat.albedo_color=c; mat.emission_enabled=true; mat.emission=c; mat.emission_energy_multiplier=energy
	m.material_override=mat; add_child(m); neon_mats.append(mat)

# ======================= HUD =======================
func _bar(parent:Control,pos:Vector2,size:Vector2,col:Color,right:bool)->ProgressBar:
	var b:=ProgressBar.new(); b.position=pos; b.size=size; b.show_percentage=false; b.max_value=100; b.value=100
	var bgs:=StyleBoxFlat.new(); bgs.bg_color=Color(.1,.05,.15,.85); bgs.border_color=Color(1,1,1,.6); bgs.set_border_width_all(2)
	var fg:=StyleBoxFlat.new(); fg.bg_color=col
	b.add_theme_stylebox_override("background",bgs); b.add_theme_stylebox_override("fill",fg)
	if right: b.fill_mode=ProgressBar.FILL_END_TO_BEGIN
	parent.add_child(b); return b
func _build_hud()->void:
	hud=CanvasLayer.new(); add_child(hud)
	var root:=Control.new(); root.set_anchors_preset(Control.PRESET_FULL_RECT); root.mouse_filter=Control.MOUSE_FILTER_IGNORE; hud.add_child(root)
	vign=ColorRect.new(); vign.set_anchors_preset(Control.PRESET_FULL_RECT); vign.color=Color(0,0,0,0); vign.mouse_filter=Control.MOUSE_FILTER_IGNORE
	var vs:=Shader.new(); vs.code="shader_type canvas_item;uniform float a=0.;void fragment(){float d=distance(UV,vec2(.5));COLOR=vec4(0,0,0,smoothstep(.35,.75,d)*a);}"
	var vm:=ShaderMaterial.new(); vm.shader=vs; vign.material=vm; root.add_child(vign)
	for i in 2:
		var x:=24.0 if i==0 else 1280.0-24.0-520.0
		hp_bars.append(_bar(root,Vector2(x,18),Vector2(520,26),Color("#ffd23c") if i==1 else Color("#b45cff"),i==1))
		hype_bars.append(_bar(root,Vector2(x,48),Vector2(260 ,8),Color("#ff7a2a"),i==1)); if i==1: hype_bars[1].position.x=1280-24-260
		var nl:=UI.label("",18); nl.position=Vector2(x,58); nl.size=Vector2(520,24); nl.horizontal_alignment=HORIZONTAL_ALIGNMENT_LEFT if i==0 else HORIZONTAL_ALIGNMENT_RIGHT; root.add_child(nl); name_l.append(nl)
		var wl:=UI.label("",16,Color("#ffd23c")); wl.position=Vector2(x,80); wl.size=Vector2(520,20); wl.horizontal_alignment=nl.horizontal_alignment; root.add_child(wl); wins_l.append(wl)
	timer_l=UI.label("99",40,Color.WHITE); timer_l.position=Vector2(600,8); timer_l.size=Vector2(80,50); root.add_child(timer_l)
	sub_l=UI.label("NEON YARD",14,Color("#c9a7ff")); sub_l.position=Vector2(440,58); sub_l.size=Vector2(400,20); root.add_child(sub_l)
	msg_l=UI.label("",72,Color("#ffd23c")); msg_l.position=Vector2(0,250); msg_l.size=Vector2(1280,100); root.add_child(msg_l)
	combo_l=UI.label("",30,Color("#ff8ad8")); combo_l.position=Vector2(20,110); combo_l.size=Vector2(400,40); combo_l.horizontal_alignment=HORIZONTAL_ALIGNMENT_LEFT; root.add_child(combo_l)
	flash_r=ColorRect.new(); flash_r.set_anchors_preset(Control.PRESET_FULL_RECT); flash_r.color=Color(1,1,1,0); flash_r.mouse_filter=Control.MOUSE_FILTER_IGNORE; root.add_child(flash_r)
	# cutscene dialogue
	cut_panel=PanelContainer.new(); cut_panel.position=Vector2(180,520); cut_panel.size=Vector2(920,170); cut_panel.add_theme_stylebox_override("panel",UI.style(Color("#ff3b6b"),.8)); cut_panel.visible=false
	var h:=HBoxContainer.new(); h.add_theme_constant_override("separation",16); cut_panel.add_child(h)
	cut_pic=TextureRect.new(); cut_pic.custom_minimum_size=Vector2(140,140); cut_pic.expand_mode=TextureRect.EXPAND_IGNORE_SIZE; cut_pic.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_COVERED; h.add_child(cut_pic)
	var v:=VBoxContainer.new(); h.add_child(v); cut_name=UI.label("",22,Color("#ff6b8b")); cut_name.horizontal_alignment=HORIZONTAL_ALIGNMENT_LEFT; v.add_child(cut_name)
	cut_text=UI.label("",20); cut_text.horizontal_alignment=HORIZONTAL_ALIGNMENT_LEFT; cut_text.autowrap_mode=TextServer.AUTOWRAP_WORD; cut_text.custom_minimum_size=Vector2(720,90); v.add_child(cut_text)
	root.add_child(cut_panel)
	var bn:=UI.button("NEXT ▶",_cut_next); bn.position=Vector2(900,20); bn.name="cutnext"; bn.visible=false; root.add_child(bn)
	var bs:=UI.button("SKIP CUTSCENE",_cut_skip,Color("#ffd23c")); bs.position=Vector2(1040,20); bs.name="cutskip"; bs.visible=false; root.add_child(bs)

# ======================= ROUND FLOW =======================
func _reset_fighters()->void:
	var r:Dictionary=Game.rules
	for i in 2:
		var f:=F[i]; f.x=330.0 if i==0 else 630.0; f.y=GROUND; f.vx=0; f.vy=0; f.face=1 if i==0 else -1; f.yaw=PI/2*f.face
		var hpv:float=f.d.stats.hp*(r.get("cpuHp",1.0) if i==1 else 1.0); f.hp=hpv; f.maxhp=hpv
		var mf:int=r.get("modeFull",0); f.hype=100.0 if (mf>0 and (i==0 or mf==2)) else 0.0
		f.st="idle"; f.mv={}; f.mode=0; f.queue=[]; f.seq_t=[]; f.seq_m=[]; f.chain_n=0; f.combo=0; f.rz=0; f.zoff=0; f.air=false; f.landed=0; f.down_t=0; f.jug=0; f.spin=0
		f.stop_action(); f.loco("idle"); f.sync_visual(0.0,1.0)
		name_l[i].text=f.d.name+" · "+f.d.tag
func _start_round()->void:
	phase="fight"; _reset_fighters()
	timer=int(Game.rules.get("time",99)); tick=0; ko_t=0; winner=-1
	var banner:String=Game.rules.get("banner","")
	msg=banner if (banner!="" and round_n==1) else "ROUND %d"%round_n; msg_t=90
	var fin:=round_n>=3 or (F[0].wins==1 and F[1].wins==1)
	Sfx.say("final" if fin else ("round2" if round_n==2 else "round1"),.15); Sfx.play("bell"); Sfx.music("fight"); Sfx.crowd(true)
	Game.log_line("ROUND %d start %s vs %s"%[round_n,F[0].d.id,F[1].d.id])
func end_round(w:int,t:String)->void:
	if ko_t>0: return
	if w>=0: F[w].wins+=1
	winner=w; msg=t; msg_t=150; ko_t=150
	stats.rounds.append({"round":round_n,"winner":w,"how":t,"hp":[snappedf(F[0].hp,.1),snappedf(F[1].hp,.1)],"time":timer})
	Game.log_line("ROUND %d over: %s winner=%s hp=%s"%[round_n,t,(F[w].d.id if w>=0 else "draw"),[int(F[0].hp),int(F[1].hp)]])
	if t=="K.O." and w>=0:
		slow=150; ko_cam={"i":1-w,"t":0.0,"ang":0.8 if F[1-w].face>0 else -0.8}
		_flash(.3); Sfx.play("ko"); Sfx.say("ko",.05); Sfx.play("crowd_roar")
		if Game.autotest=="shots" and not shot_ko: shot_ko=true; _delayed_shot("ko_slowmo",.9)
		if F[w].hp>=F[w].maxhp-.5: Sfx.say("perfect",1.3)
	else:
		Sfx.play("bell"); Sfx.say("timeup")

# ======================= MAIN LOOP =======================
var acc:=0.0
func _process(dt:float)->void:
	dt=minf(dt,.1)
	if phase=="cut": _cut_step(dt); _sync(dt,1.0); return
	var ts:=1.0
	if slow>0: ts=.2 if slow>110 else (.35 if slow>40 else .7)
	if intro.size()>0: ts=.25
	acc+=dt*ts
	var n:=0
	while acc>=1.0/60.0 and n<6:
		if phase=="fight": _update()
		acc-=1.0/60.0; n+=1
	_sync(dt*ts,1.0 if hitstop<=0 else .05)
	_hud()
func _physics_process(_d:float)->void: pass

func inp(p:int)->Dictionary:
	var pre:="p1_" if p==0 else "p2_"; var o:={}
	for a in ["left","right","up","down","lp","hp","gr","ct","sp"]:
		var k:String={"left":"l","right":"r","up":"u","down":"b"}.get(a,a)
		o[k]=Input.is_action_pressed(pre+a); o["p_"+k]=Input.is_action_just_pressed(pre+a)
	return o

func free_st(f:Fighter)->bool: return f.st=="idle" or f.st=="walk" or f.st=="block"

func strings_of(d:Dictionary)->Array: return d.strings+Game.UNI
func resolve_start(f:Fighter,a:String,I:Dictionary)->String:
	if a=="gr" or a=="ct" or a=="sp": return a
	if f.y<GROUND: return "airkick"
	var fw:bool=I.get("r",false) if f.face>0 else I.get("l",false)
	var bk:bool=I.get("l",false) if f.face>0 else I.get("r",false)
	if I.get("b",false): return "lowkick" if a=="lp" else "sweep"
	if a=="hp" and fw: return "hay"
	if a=="hp" and bk: return "upper"
	return "jab" if a=="lp" else "cross"
func next_in_string(f:Fighter,tok:String)->Dictionary:
	var s:Array=f.seq_t+[tok]
	for S in strings_of(f.d):
		if S.seq.size()<s.size(): continue
		var ok:=true
		for i in s.size(): if S.seq[i]!=s[i]: ok=false
		for i in f.seq_m.size(): if i>=S.mv.size() or S.mv[i]!=f.seq_m[i]: ok=false
		if ok: return {"S":S,"mv":S.mv[s.size()-1]}
	return {}

func ai(f:Fighter,o:Fighter)->Dictionary:
	if f.passive and f.queue.is_empty() and f.st!="held": return {}
	var r:={}; var dx:=o.x-f.x; var dist:=absf(dx); var toward:="r" if dx>0 else "l"; var away:="l" if dx>0 else "r"
	var lvl:float=Game.rules.get("cpuLevel",1.0) if (f.idx==1 or Game.auto_both) else 1.0
	if f.st=="held":
		if randf()<.25*lvl: r["p_lp"]=true
		return r
	if f.st=="hold":
		if f.hold_n<1 and randf()<.08: r["p_lp"]=true
		elif f.t>20 and randf()<.1:
			r["p_hp"]=true
			if randf()<.3: r[away]=true
		return r
	if not f.queue.is_empty():
		var nx:String=f.queue[0]
		if free_st(f) or (f.st=="atk" and f.hit and f.t>=f.mv.st+f.mv.ac-1): r["p_"+nx]=true; f.queue.pop_front()
		if f.st=="hurt" or f.st=="down": f.queue=[]
		return r
	f.ai_t-=1
	if f.ai_t>0: r.merge(f.ai_hold); return r
	f.ai_t=float(int(5+randf()*9))/maxf(.6,lvl)
	var h:={}
	if o.st=="down" and o.landed>0 and dist<150 and free_st(f) and randf()<.3: h["otg"]=true
	if f.hype>=100 and f.mode==0 and free_st(f): h["p_sp"]=true
	elif o.st=="atk" and not o.mv.is_empty() and o.t<o.mv.st+1 and dist<180:
		var q:=randf()
		if q<.25: h["p_ct"]=true
		elif q<.7: h["b"]=true
		else: h[away]=true
	elif o.air and o.st=="down" and dist<170 and free_st(f): h["p_lp"]=true
	elif dist>150:
		h[toward]=true
		if randf()<.03: h["p_u"]=true
	elif free_st(f):
		var q:=randf(); var S:=strings_of(f.d)
		if f.mode>0 and q<.3: f.queue=["lp","hp","sp"]
		elif q<.12: h["p_gr"]=true
		elif q<.2: h["b"]=true; h["p_lp"]=true
		elif q<.75: f.queue=S[randi()%mini(S.size(),4)].seq.duplicate()
		elif q<.88: h["b"]=true
		else: h[away]=true
	f.ai_hold={}
	for k in h: if not String(k).begins_with("p_"): f.ai_hold[k]=h[k]
	r.merge(h); return r

func mv_of(name:String)->Dictionary: return Game.MV[name].duplicate()
func start_atk(f:Fighter,name:String,I:Dictionary)->void:
	f.st="atk"; var m:=mv_of(name); m["k"]=name
	if name=="sp" and f.mode>0: m.merge(Game.SPV.get(f.d.id,{}),true)
	f.mv=m; f.hits=0; f.last_hit_t=-99; f.t=0; f.hit=false; f.ct=name=="ct"; f.buf=""; f.buf_t=0
	if name=="sp" and f.mode>0:
		_special(f)
	if name=="sp" and f.mode==0:
		f.mode=480; f.hype=0; f.mv=mv_of("mact"); f.mv["k"]="mact"; _begin_intro(f)
	var clip:String=f.mv.clip; var cf:float=f.mv.get("cf",0.0); var dur:=f.clip_len(clip); var spd:float=(1.3 if f.mode>0 else 1.0)*f.d.stats.spd
	var tsc:float
	if cf>0: tsc=clampf(dur*cf/((f.mv.st+1)/60.0),0.6,3.4)*spd*.55
	else: tsc=dur/((f.mv.st+f.mv.ac+f.mv.rc)/60.0)
	f.action(clip,tsc,.05 if f.chain_n>0 else .08)
	if f.mv.get("dmg",0)>0: Sfx.play("whoosh_heavy" if f.mv.dmg>10 else "whoosh_light",-6)

func path_at(P:Array,fr:float)->Array:
	if fr<=P[0][0]: return P[0]
	for i in range(1,P.size()):
		if fr<=P[i][0]:
			var a:Array=P[i-1]; var b:Array=P[i]; var q:float=(fr-a[0])/(b[0]-a[0])
			return [fr,lerpf(a[1],b[1],q),lerpf(a[2],b[2],q),lerpf(a[3],b[3],q)]
	return P[P.size()-1]
func start_hold(f:Fighter,o:Fighter)->void:
	f.st="hold"; f.t=0; f.hold_n=0; f.mv={}; o.st="held"; o.t=0; o.mash=0; o.mv={}; o.ct=false; o.queue=[]; o.vx=0; o.vy=0; o.face=-f.face
	f.stop_action(); o.stop_action(); f.loco("hold"); o.loco("held"); hitstop=4; msg=""; Sfx.play("grab")
func release_hold(f:Fighter,o:Fighter,brk:bool)->void:
	f.st="idle"; o.st="hurt"; o.stun=10 if brk else 16; o.rz=0; f.vx=-f.face*6; o.vx=f.face*7; f.chain_n=0
	if brk:
		f.st="hurt"; f.stun=14; o.action("Break_Free",1.4); msg="BREAK!"; msg_t=30; Sfx.play("counter"); fx.emit("impact",(f.global_position+o.global_position)/2+Vector3(0,1.3,0))
func start_throw(f:Fighter,o:Fighter,I:Dictionary)->void:
	var tk:String=f.d.throw; var T:Dictionary=Game.THROWS[tk]
	var bk:bool=I.get("l",false) if f.face>0 else I.get("r",false)
	if bk: f.face=-f.face; f.yaw=PI/2*f.face; o.face=-f.face
	f.st="throw"; f.t=0; f.thr=T; o.st="thrown"; o.t=0; o.loco("tumble"); f.impacted=false; f.stomped=false
	stats.throws+=1; f.action(T.clip,1.0,.08); msg=T.n; msg_t=45; Sfx.play("grab")
	Game.log_line("THROW %s %s"%[f.d.id,T.n])
func step_throw(f:Fighter,o:Fighter)->void:
	var T:Dictionary=f.thr; f.t+=1; var fr:float=f.t/2.0; var sc:float=f.d.scale[1]
	if o.st=="thrown":
		var p:=path_at(T.path,minf(maxf(0,fr-3),T.rel)); var dx:float=p[1]; var dy:float=p[2]; var rr:float=p[3]
		if T.get("spin",0):
			var a:=fr/24.0*PI*4; dx=cos(a)*62; o.zoff=sin(a)*.4; rr=0; o.face=-f.face if cos(a)>0 else f.face
		o.x=f.x+f.face*dx; o.y=GROUND-dy*sc; o.rz=rr*f.face*.85
		if T.impact>0 and fr>=T.impact and not f.impacted:
			f.impacted=true; hurt_by(f,o,T.dmg); shake=.3; cam_kick=.5; hitstop=9; _slam(o,1.0)
		if fr>=T.rel:
			o.zoff=0; o.st="down"; o.air=true; o.landed=0; o.vx=f.face*T.vx; o.vy=T.vy; o.y=minf(o.y,GROUND-2); o.down_t=9999 if o.hp<=0 else 52; o.spin=f.face*.13 if T.vx>8 else 0.0
			if T.impact==0: o.pending_dmg=T.dmg; o.pending_by=f
			if o.hp<=0: end_round(f.idx,"K.O.")
	if T.get("stomp",0) and fr>=T.stomp and not f.stomped:
		f.stomped=true
		if o.st=="down" and absf(o.x-f.x)<170: hurt_by(f,o,T.stompDmg); shake=.2; hitstop=6; _slam(o,.5)
	if f.t>=f.clip_len(T.clip)*60-2: f.st="idle"; f.thr={}; f.chain_n=0; f.stop_action()
func hurt_by(f:Fighter,o:Fighter,dmg:float)->void:
	var dd:float=dmg*(1.35 if f.mode>0 else 1.0)*f.d.stats.pow; o.hp=maxf(0,o.hp-dd); o.flash=6; f.combo+=1; f.combo_t=60
	if f.mode==0: f.hype=minf(100,f.hype+8)
	o.hype=minf(100,o.hype+4)
	if o.hp<=0 and ko_t==0: end_round(f.idx,"K.O.")

func zone_of(m:Dictionary)->String:
	var c:String=m.get("clip","")
	if m.get("low",0) or c.contains("Sweep") or c.contains("Kick_Low"): return "leg"
	if c.contains("Knee") or c.contains("Kick_Front") or c.contains("Stomp"): return "body"
	return "head"
func limb_of(c:String)->String:
	if c.contains("Kick") or c.contains("Knee") or c.contains("Stomp") or c.contains("Sweep") or c.contains("Roundhouse") or c.contains("Air"): return "DEF-foot.R"
	if c.contains("Jab") or c.contains("Hook_L"): return "DEF-hand.L"
	return "DEF-hand.R"

func try_hit(f:Fighter,o:Fighter,m:Dictionary,I:Dictionary)->void:
	var rel:=(o.x-f.x)*f.face
	var in_range:bool
	if m.get("aoe",0): in_range=absf(o.x-f.x)<m.rng and (not m.get("front",0) or rel>-40)
	else:
		in_range=rel>0 and rel<m.rng and absf(o.y-f.y)<(150.0 if m.get("air",0) else (230.0 if o.jug>0 else 110.0))
		# physical check: the striking limb's Area3D overlapping the opponent's hurtbox (or the frame-data range)
		var a:Area3D=f.hit_areas.get(limb_of(m.get("clip","")))
		if a and a.overlaps_area(o.hurt): in_range=true; stats["box_hits"]=stats.get("box_hits",0)+1
	if not in_range: return
	var juggle:bool=o.st=="down" and o.air and o.jug>0 and o.jug<4 and not m.get("grab",0)
	var otg:bool=o.st=="down" and not o.air and m.get("otg",0)
	if (o.st=="down" and not juggle and not otg) or o.st=="rise" or o.st=="held" or o.st=="thrown": return
	f.hit=true
	if m.get("multi",0):
		f.hits+=1; f.last_hit_t=f.t
		if f.hits>=5: m["kd"]=1
	if m.get("grab",0):
		if o.y<GROUND or o.st=="down": f.hit=false; return
		start_hold(f,o); return
	if o.ct and o.st=="atk" and o.t<o.mv.st+o.mv.ac and not m.get("aoe",0):
		o.ct=false; f.st="hurt"; f.stun=34; f.mv={}; f.vx=-f.face*4; o.chain_n=0; o.seq_t=[]; o.seq_m=[]; start_atk(o,"cross",{}); o.mv.st=2; o.hype=minf(100,o.hype+15)
		msg=String(o.d.moves.ct).to_upper()+"!"; msg_t=40; hitstop=10; stats.counters+=1
		_flash(.55); Sfx.play("counter"); Sfx.play("punch_heavy_face"); f.flinch.kick("head",1.0); fx.emit("spark",(f.global_position+o.global_position)/2+Vector3(0,1.5,0)); fx.emit("flash",(f.global_position+o.global_position)/2+Vector3(0,1.5,.3)); shake=.15; cam_kick=.4
		return
	if o.st=="block" and not m.get("aoe",0) and o.face==-f.face:
		o.hp-=m.dmg*.15*f.d.stats.pow; o.vx=f.face*m.kb*.6; f.hype=minf(100,f.hype+2); o.hype=minf(100,o.hype+3); hitstop=2+int(m.dmg*.12); stats.blocks+=1
		var bp:=o.bone_pos("DEF-hand.L"); fx.emit("block",bp,Color(.5,.85,1),Vector3(-f.face,0.3,0)); fx.emit("flash",bp,Color(.35,.7,1)); o.flinch.kick("body",.12); Sfx.play("block"); cam_kick=maxf(cam_kick,.05)
		return
	var dmg:float=m.dmg*(1.5 if f.mode>0 else 1.0)*f.d.stats.pow; f.combo+=1; f.combo_t=60
	if f.combo>1: dmg*=1+mini(f.combo,6)*.05
	if juggle: dmg*=maxf(.45,1-o.jug*.18)
	o.hp=maxf(0,o.hp-dmg); o.flash=6; o.mv={}; o.ct=false; o.queue=[]; o.seq_t=[]; o.seq_m=[]; stats.hits+=1
	var dir:int=(1 if o.x>f.x else -1) if m.get("aoe",0) else f.face
	if m.get("fin",""): msg=m.fin; msg_t=40
	if juggle: o.jug+=1; stats.juggles+=1; o.vy=minf(o.vy,-7.5); o.vx=dir*3; o.down_t=48
	elif m.get("launch",0) and o.hp>0:
		o.st="down"; o.jug=1; o.vx=dir*2.5; o.vy=-15.5; o.y=GROUND-2; o.air=true; o.landed=0; o.down_t=48; o.face=-dir; o.stop_action(); o.loco("launched")
		if msg=="": msg="LAUNCH!"; msg_t=25
	elif m.get("kd",0) or o.hp<=0:
		o.st="down"; o.jug=0; o.vx=dir*(m.kb*.7+3); o.vy=-5.0 if m.get("sweep",0) else -8.5; o.y=GROUND-2; o.air=true; o.landed=0; o.down_t=9999 if o.hp<=0 else 48; o.face=-dir; o.stop_action()
		if m.get("sweep",0): o.spin=-dir*.12
	elif otg: o.down_t=maxi(o.down_t,20)
	else:
		o.st="hurt"; o.stun=int(m.hs); o.vx=dir*m.kb*.75; o.light_hurt=m.dmg<=9 and f.mode==0
		if not o.light_hurt: o.action("Hit_Head" if zone_of(m)=="head" else "Hit_Chest",1.6,.05)
	if f.mode==0: f.hype=minf(100,f.hype+m.get("hy",0)+f.combo*2)
	o.hype=minf(100,o.hype+3)
	# ---- juice ----
	var zone:=zone_of(m); var strn:=minf(1.6,m.dmg/10.0); var hv:bool=m.dmg>10 or m.get("kd",0) or m.get("launch",0)
	hitstop=maxi(hitstop,int(round(3+m.dmg*.42+(3 if m.get("kd",0) else 0)+(2 if f.mode>0 else 0))))
	shake=maxf(shake,.03+strn*.07); cam_kick=maxf(cam_kick,.12+strn*.32)
	var hb:=o.bone_pos("DEF-head" if zone=="head" else ("DEF-spine.002" if zone=="body" else "DEF-shin.L"))
	fx.emit("spark",hb,Color(1,.95,.75),Vector3(-dir,0.2,0)); fx.emit("impact",hb,Color(f.d.col),Vector3(dir,.3,0)); fx.emit("flash",hb+Vector3(0,0,.2),Color(f.d.col).lightened(.5))
	if zone=="head": fx.emit("sweat",hb+Vector3(0,.05,0),Color(.75,.9,1,.9),Vector3(dir,1,0))
	o.flinch.kick(zone,.35+strn*.5)
	Sfx.play("punch_%s_%s"%["heavy" if hv else "light","face" if zone=="head" else "body"])
	if hv: Sfx.play("crowd_cheer",-6)
	if Game.autotest=="shots" and hv and not shot_hit and tick>200: shot_hit=true; _delayed_shot("hit_spark",.05)
	if o.hp<=0: end_round(f.idx,"K.O.")

func _update()->void:
	if hitstop>0: hitstop-=1; return
	tick+=1
	if Game.autotest=="shots" and tick==420: _delayed_shot("midfight",0.0)
	if msg_t>0: msg_t-=1
	if msg_t==46 and (msg.begins_with("ROUND") or msg==Game.rules.get("banner","")): msg="FIGHT!"; msg_t=45; Sfx.say("fight"); Sfx.play("crowd_cheer",-4)
	if ko_t>0:
		ko_t-=1
		if ko_t==0:
			if F[0].wins>=2 or F[1].wins>=2: _match_over(); return
			round_n+=1; _start_round(); return
	elif msg_t<60 and tick%60==0 and timer>0:
		timer-=1
		if timer==0:
			var a:=F[0].hp/F[0].maxhp; var b:=F[1].hp/F[1].maxhp
			end_round(-1 if is_equal_approx(a,b) else (0 if a>b else 1),"TIME")
	var live:bool=ko_t==0 and not ((msg.begins_with("ROUND") or msg==Game.rules.get("banner","")) and msg_t>0) and intro.is_empty()
	for i in 2:
		var f:=F[i]; var o:=F[1-i]
		var I:Dictionary={}
		if live:
			if Game.auto_both or (i==1 and Game.vs_cpu) or (not f.queue.is_empty() and i==0 and Game.auto_both): I=ai(f,o)
			else: I=inp(i)
		_step_fighter(f,o,I,live)
	var dx:=F[1].x-F[0].x; var pairing:bool=F[0].st in ["hold","throw"] or F[1].st in ["hold","throw"]
	if not pairing and absf(dx)<100 and absf(F[0].y-F[1].y)<120 and F[0].st!="down" and F[1].st!="down":
		var p:=(100-absf(dx))/2*signf(dx if dx!=0 else 1.0); F[0].x-=p*.6; F[1].x+=p*.6
	_update_specials()

func _step_fighter(f:Fighter,o:Fighter,I:Dictionary,live:bool)->void:
	for a in ["lp","hp","gr","ct","sp"]:
		if I.get("p_"+a,false): f.buf=a; f.buf_t=9
	if f.buf_t>0: f.buf_t-=1
	else: f.buf=""
	if f.mode>0:
		f.mode-=1
	if f.flash>0: f.flash-=1
	var spd:float=(1.3 if f.mode>0 else 1.0)*f.d.stats.spd; var on_g:=f.y>=GROUND
	if f.st=="held" or f.st=="thrown":
		if f.st=="held" and (I.get("p_lp",false) or I.get("p_hp",false) or I.get("p_gr",false) or I.get("p_l",false) or I.get("p_r",false)): f.mash+=1
		if f.st=="held" and f.mash>=10: release_hold(o,f,true)
		f.buf=""; return
	if f.st=="hold":
		f.t+=1; o.x=f.x+f.face*62; o.y=GROUND-6; o.face=-f.face
		if f.strike_t>0:
			f.strike_t-=1
			if f.strike_t==8: hurt_by(f,o,4); shake=.06; hitstop=3; Sfx.play("punch_light_body"); fx.emit("impact",o.bone_pos("DEF-spine.002"),Color(f.d.col)); o.flinch.kick("body",.5)
		elif f.buf=="lp" and f.hold_n<3: f.hold_n+=1; f.strike_t=16; f.buf=""; f.action("Grab_Knee" if f.hold_n%2 else "Grab_Punch",1.1)
		elif f.buf=="hp" or f.buf=="gr" or (f.hold_n>=3 and f.t>40): f.buf=""; start_throw(f,o,I)
		if f.t>150 and f.st=="hold": release_hold(f,o,false)
		if o.hp<=0 and f.st=="hold": f.st="idle"; o.st="down"; o.down_t=9999
		return
	if f.st=="throw": step_throw(f,o); return
	if f.st=="down":
		f.vx*=.88 if on_g else .99
		if f.air: f.rz+=f.spin
		else: f.rz*=.6
		if f.down_t>0 and f.landed>=1: f.down_t-=1
		if f.down_t==0 and f.hp>0: f.st="rise"; f.t=0; f.rz=0; f.jug=0; f.loco("idle"); f.rise_anim_play(28/60.0)
	elif f.st=="rise":
		f.t+=1; f.vx*=.8
		if f.t>28: f.st="idle"
	elif f.st=="hurt":
		f.stun-=1; f.vx*=.86
		if f.stun<=0: f.st="block" if I.get("b",false) else "idle"; f.chain_n=0; f.light_hurt=false
	elif f.st=="atk":
		var m:Dictionary=f.mv; f.t+=spd
		if m.get("lunge",0) and f.t>=m.st and f.t<m.st+2: f.vx=f.face*m.lunge*.18
		if not m.get("air",0): f.vx*=.82
		if m.get("dash",0) and f.t>=m.st and f.t<m.st+m.ac:
			var gap:=(o.x-f.x)*f.face; f.vx=f.face*14.0 if gap>90 else 0.0
		if m.get("multi",0) and f.hit and f.t-f.last_hit_t>=5 and f.hits<5: f.hit=false
		if f.t>=m.st and f.t<m.st+m.ac and not f.hit and (m.get("dmg",0)>0 or m.get("grab",0)): try_hit(f,o,m,I)
		if f.st!="atk": return
		if m.get("air",0) and on_g and f.t>4: f.st="idle"; f.mv={}; f.action("Jump_Land",1.8); f.land_t=10; return
		var nx:={}
		if (f.buf=="lp" or f.buf=="hp") and f.hit and f.t>=m.st+m.ac-1 and f.t<m.st+m.ac+m.rc*.85 and not f.seq_t.is_empty(): nx=next_in_string(f,f.buf)
		var sp_chain:bool=f.buf=="sp" and f.mode>0 and f.hit and f.t>=m.st+m.ac-1 and not m.get("aoe",0)
		if not nx.is_empty():
			f.chain_n+=1; f.seq_t.append(f.buf); f.seq_m.append(nx.mv); var last:bool=f.seq_t.size()==nx.S.seq.size()
			start_atk(f,nx.mv,I)
			if last and nx.S.n!="": f.mv["fin"]=nx.S.n; stats.strings[f.d.id+":"+nx.S.n]=true
		elif sp_chain: f.chain_n+=1; start_atk(f,"sp",I)
		elif f.t>=m.st+m.ac+m.rc: f.st="idle"; f.mv={}; f.ct=false; f.chain_n=0; f.seq_t=[]; f.seq_m=[]; f.stop_action()
	elif f.hp>0 and live:
		var blk:bool=I.get("b",false) and on_g and f.buf==""
		if not blk:
			if I.get("l",false): f.vx+=(-4.2*spd-f.vx)*.35
			elif I.get("r",false): f.vx+=(4.2*spd-f.vx)*.35
			else: f.vx*=.7 if on_g else .98
		else: f.vx*=.6
		if I.get("p_u",false) and on_g and not blk: f.vy=-13.5; f.action("Jump_Start",2.2); f.jump_t=8
		if I.get("otg",false) and o.st=="down" and o.landed>0: start_atk(f,"stomp",I); f.seq_t=[]; f.seq_m=["stomp"]
		elif f.buf!="" and not (f.buf=="sp" and f.mode==0 and f.hype<100):
			var nm:=resolve_start(f,f.buf,I)
			if (f.buf=="lp" or f.buf=="hp") and nm!="airkick" and o.st=="down" and o.landed>0 and absf(o.x-f.x)<160 and I.get("b",false): nm="stomp"
			f.seq_t=[f.buf] if (f.buf=="lp" or f.buf=="hp") else []; f.seq_m=[nm]
			start_atk(f,nm,I)
		else: f.st="block" if blk else ("walk" if absf(f.vx)>.6 and on_g else "idle")
	elif f.st!="atk" and f.st!="hurt": f.st="idle"
	f.vy+=.62 if (f.st=="down" and f.jug>0) else .72; f.x+=f.vx; f.y+=f.vy
	# wall / fence slam
	if (f.x<=WALL_L or f.x>=WALL_R) and f.st=="down" and f.air and absf(f.vx)>7 and not f.walled:
		f.walled=true; f.vx=-f.vx*.3; f.vy=-4; stats.walls+=1; hurt_by(o,f,6); shake=.35; cam_kick=.4; hitstop=8; msg="WALL SLAM!"; msg_t=35
		Sfx.play("fence"); fx.emit("impact",f.global_position+Vector3(0,1.2,0)); Game.log_line("WALL SLAM")
	if f.y>=GROUND:
		f.y=GROUND
		if f.air:
			if f.st=="down":
				f.landed+=1; f.jug=0; f.walled=false
				if f.pending_dmg>0: hurt_by(f.pending_by,f,f.pending_dmg); f.pending_dmg=0; shake=.25; hitstop=5
				if f.landed==1: f.vy=-2.2; f.y=GROUND-1; shake=maxf(shake,.12); _slam(f,.6)
				else: f.vy=0; f.spin=0
			else:
				f.vy=0
				if free_st(f): f.action("Jump_Land",1.8); f.land_t=10; Sfx.play("land",-8)
		else: f.vy=0
	f.air=f.y<GROUND; f.x=clampf(f.x,WALL_L,WALL_R)
	# facing hysteresis: only flip when clearly crossed, never mid-air, with a cooldown (no spinning)
	if (free_st(f) or f.st=="rise") and f.y>=GROUND-1:
		var ddx:=o.x-f.x
		if ddx*f.face< -24 or (f.st=="rise" and ddx*f.face<0):
			if f.flip_t==0: f.face=-f.face; stats.flips[f.idx]+=1
			f.flip_t=12
	if f.flip_t>0: f.flip_t-=1
	if f.combo_t>0:
		f.combo_t-=1
		if f.combo_t==0: f.combo=0
	if f.jump_t>0: f.jump_t-=1
	if f.land_t>0: f.land_t-=1
	if f.st=="walk":
		f.step_acc+=absf(f.vx)
		if f.step_acc>55: f.step_acc=0; Sfx.play("step",-10)
	_anim_select(f)

func _anim_select(f:Fighter)->void:
	if f.st in ["atk","rise","hold","throw"]: return
	if f.st=="held": f.loco("held"); return
	if f.st=="thrown": f.loco("tumble"); return
	if f.st=="down":
		if f.air and (f.jug>0 or f.spin!=0): f.loco("tumble" if f.spin!=0 else "launched")
		else: f.loco("down",f.clip_len("Death01")/0.6)
		return
	if f.st=="hurt": f.loco("idle"); return
	if ko_t>0 and winner==f.idx and ko_t<110: f.loco("win"); return
	if f.air:
		if f.jump_t==0: f.loco("jump")
		return
	if f.land_t>0: return
	if f.st=="block": f.loco("block"); return
	if f.st=="walk":
		var back:bool=signf(f.vx)!=f.face
		f.loco("walk",(-1.0 if back else 1.0)*maxf(.6,absf(f.vx)/3.2)); return
	f.loco("idle")

# ======================= MODES =======================
func _begin_intro(f:Fighter)->void:
	intro={"f":f,"t":0.0,"T":1.3}; stats.modes+=1
	msg=f.d.mode; msg_t=70; Sfx.play("sting_"+f.d.id); Sfx.play("crowd_roar",-4); fx.emit("aura",f.global_position+Vector3(0,1,0),Color(f.d.col))
	Game.log_line("MODE %s %s"%[f.d.id,f.d.mode])
func _special(f:Fighter)->void:
	stats.specials+=1; msg=String(f.d.moves.sp).to_upper(); msg_t=40
	var ring:=MeshInstance3D.new(); var tm:=TorusMesh.new(); tm.inner_radius=.35; tm.outer_radius=.45; ring.mesh=tm
	var m:=StandardMaterial3D.new(); m.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED; m.albedo_color=Color(f.d.col); m.emission_enabled=true; m.emission=Color(f.d.col); m.emission_energy_multiplier=4; m.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	ring.material_override=m; add_child(ring); ring.global_position=f.global_position+Vector3(0,.1,0)
	specials.append({"n":ring,"t":0}); fx.emit("aura",f.global_position+Vector3(0,1,0),Color(f.d.col)); Sfx.play("hype"); shake=.2
func _update_specials()->void:
	for s in specials.duplicate():
		s.t+=1; var q:float=s.t/30.0; s.n.scale=Vector3.ONE*(1+q*6); (s.n.material_override as StandardMaterial3D).albedo_color.a=1-q
		if s.t>=30: s.n.queue_free(); specials.erase(s)
	if not intro.is_empty():
		intro.t+=1.0/60.0
		if intro.t>=intro.T: intro={}

# ======================= VISUAL SYNC / CAMERA =======================
func _sync(dt:float,anim_scale:float)->void:
	for f in F: f.sync_visual(dt,anim_scale)
	if F.is_empty(): return
	var a:=F[0].global_position; var b:=F[1].global_position
	if not intro.is_empty():
		var f:Fighter=intro.f; var q:float=intro.t/intro.T; var ang:float=(.9-q*.6)*f.face; var dd:=3.2-q*.8
		cam.global_position=f.global_position+Vector3(sin(ang)*dd,1.3+q*.3,cos(ang)*dd); cam.look_at(f.global_position+Vector3(0,1.15,0))
	elif slow>0 and not ko_cam.is_empty():
		slow-=1; ko_cam.t+=dt; var L:=F[ko_cam.i]; var Wn:=F[1-ko_cam.i]
		var mx:=L.global_position.x*.7+Wn.global_position.x*.3; var ang2:float=ko_cam.ang+ko_cam.t*.25; var d2:=4.6-minf(1.0,ko_cam.t*.5)*1.2
		cam.global_position=Vector3(mx+sin(ang2)*d2,1.35,cos(ang2)*d2); cam.look_at(Vector3(mx,minf(1.2,L.global_position.y+.6),0))
		if slow==0: ko_cam={}
	elif phase!="cut":
		var mx2:=(a.x+b.x)/2; var sep:=absf(a.x-b.x)
		var tz:=6.2+sep*.6-cam_kick*1.2
		cam.position.x+=(mx2-cam.position.x)*.08; cam.position.z+=(tz-cam.position.z)*.08; cam.position.y+=(1.45-cam.position.y)*.08
		cam_target.x+=(mx2-cam_target.x)*.1; cam_target.y=1.1
		cam.look_at(cam_target+Vector3(randf_range(-.5,.5)*shake,randf_range(-.5,.5)*shake,0))
	cam_kick*=.88; shake*=.85
	(vign.material as ShaderMaterial).set_shader_parameter("a",clampf(slow/40.0,0,1) if slow>0 else 0.0)
	flash_r.color.a=maxf(0,flash_r.color.a-.06)
func _flash(a:float)->void: flash_r.color=Color(1,1,1,a)
func _slam(o:Fighter,big:float)->void:
	fx.emit("dust",Vector3(o.global_position.x,.05,0),Color(.55,.5,.62,.55)); Sfx.play("slam",-2 if big>.9 else -6)
	if o.x<140 or o.x>820: Sfx.play("fence",-4)
	if big>.9: Sfx.play("crowd_cheer",-4)

func _hud()->void:
	for i in 2:
		var f:=F[i]; hp_bars[i].value=100*f.hp/f.maxhp; hype_bars[i].value=(100.0*f.mode/480.0) if f.mode>0 else f.hype
		wins_l[i].text="●".repeat(f.wins)+"○".repeat(2-f.wins)
	timer_l.text=str(timer)
	msg_l.text=msg if msg_t>0 else ""
	var c:=F[0].combo if F[0].combo>1 else (F[1].combo if F[1].combo>1 else 0)
	combo_l.text=("%d HIT COMBO!"%c) if c>1 else ""

# ======================= MATCH END / STORY =======================
func _match_over()->void:
	phase="over"; var w:=0 if F[0].wins>=2 else 1
	Game.log_line("MATCH OVER winner=%s (%s) stats=%s"%[w,F[w].d.id,JSON.stringify(stats)])
	msg=F[w].d.name+" WINS"; msg_t=999; _hud(); Sfx.say("n_"+F[w].d.id,.3); Sfx.say("win",1.6); Sfx.music("menu")
	if Game.story.get("on",false):
		var S:Dictionary=Game.SEASONS[Game.story.si]
		var won:=w==0
		if won:
			var C:Dictionary=S.ch[Game.story.ch]; var opp:String=Game.story.rival if C.opp=="RIVAL" else C.opp
			var nu:=Game.unlock(opp); Game.story.ch+=1; Game.set_season_progress(S.id,maxi(Game.season_progress(S.id),Game.story.ch))
			Game.log_line("STORY won chapter -> progress %d, unlocked %s=%s"%[Game.story.ch,opp,nu])
			if nu: msg+="\nUNLOCKED: "+Game.ROSTER[Game.ri(opp)].name
		else: Game.log_line("STORY lost chapter")
	await get_tree().create_timer(3.5).timeout
	if Game.autotest!="": Game.log_line("AUTOTEST DONE"); _autotest_quit(); return
	Game.goto("Story" if Game.story.get("on",false) else "MainMenu")
func _autotest_quit()->void:
	await get_tree().create_timer(.2).timeout
	get_tree().quit(0)

# ---- cutscene ----
func _start_cut()->void:
	var S:Dictionary=Game.SEASONS[Game.story.si]; var C:Dictionary=S.ch[Game.story.ch]
	var lines:Array=[[null,"%s — CHAPTER %d: %s"%[S.title,Game.story.ch+1,C.arena]]]+C.lines
	cut={"lines":lines,"i":-1,"t":0.0,"ch":0.0,"txt":"","shot":0}
	phase="cut"; Sfx.music("story"); Sfx.crowd(true)
	for i in 2: F[i].x=380.0 if i==0 else 580.0
	cut_panel.visible=true; hud.get_child(0).get_node("cutnext").visible=true; hud.get_child(0).get_node("cutskip").visible=true
	for hb in hp_bars+hype_bars: hb.visible=false
	_cut_next()
	if Game.autotest=="story":
		await get_tree().create_timer(1.2).timeout; Shots.shot("story_cutscene"); await get_tree().create_timer(.6).timeout; _cut_next()
		await get_tree().create_timer(.6).timeout; _cut_skip()
func _cut_next()->void:
	if phase!="cut": return
	cut.i+=1
	if cut.i>=cut.lines.size(): _cut_skip(); return
	var L:Array=cut.lines[cut.i]; var who=L[0]; cut.txt=L[1]; cut.t=0.0; cut.ch=0.0
	var id:String=""
	if who==null: id=""
	elif who=="P": id=F[0].d.id
	elif who=="RIVAL": id=Game.story.rival
	else: id=who
	cut.shot=0 if id=="" else (1 if id==F[0].d.id else 2)
	cut_name.text="" if id=="" else Game.ROSTER[Game.ri(id)].name
	cut_pic.texture=null if id=="" else load("res://art/portraits/%s.jpg"%id); cut_pic.visible=id!=""
	Game.log_line("CUT line %d %s"%[cut.i,id])
	Sfx.play("ui",-8)
func _cut_skip()->void:
	if phase!="cut": return
	cut_panel.visible=false; hud.get_child(0).get_node("cutnext").visible=false; hud.get_child(0).get_node("cutskip").visible=false
	for hb in hp_bars+hype_bars: hb.visible=true
	Game.log_line("CUT done"); _start_round()
func _cut_step(dt:float)->void:
	cut.t+=dt; cut.ch=minf(cut.txt.length(),cut.ch+dt*55); cut_text.text=cut.txt.substr(0,int(cut.ch))
	var a:=F[0].global_position.x; var b:=F[1].global_position.x; var mid:=(a+b)/2; var q:=minf(1.0,cut.t/3.0)
	for f in F: f.loco("relax")
	if cut.shot==0: cam.global_position=Vector3(mid+sin(cut.t*.2)*1.5,2.2-q*.4,7.5-q*1.2); cam.look_at(Vector3(mid,1.1,0))
	else:
		var me:=a if cut.shot==1 else b; var other:=b if cut.shot==1 else a; var s:=signf(other-me)
		cam.global_position=Vector3(me-s*.9+s*q*.15,1.55,1.9-q*.3); cam.look_at(Vector3(me+s*.15,1.45,0))
	if Input.is_action_just_pressed("p1_lp") or Input.is_action_just_pressed("ui_accept"): _cut_next()
