class_name UI
## Small helpers to build the neon UI in code (keeps scenes tiny and diff-friendly).
static func bg(parent:Control,dim:=0.55)->void:
	var t:=TextureRect.new(); t.texture=load("res://art/bg.jpg"); t.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_COVERED; t.set_anchors_preset(Control.PRESET_FULL_RECT); parent.add_child(t)
	var c:=ColorRect.new(); c.color=Color(0.03,0.0,0.08,dim); c.set_anchors_preset(Control.PRESET_FULL_RECT); parent.add_child(c)

static func label(text:String,size:=28,col:=Color.WHITE,outline:=Color("#2a0a44"))->Label:
	var l:=Label.new(); l.text=text; l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var ls:=LabelSettings.new(); ls.font_size=size; ls.font_color=col; ls.outline_size=max(2,size/7); ls.outline_color=outline
	ls.shadow_color=Color(col,0.35); ls.shadow_size=size/5; l.label_settings=ls; return l

static func style(col:Color,fill_a:=0.3)->StyleBoxFlat:
	var s:=StyleBoxFlat.new(); s.bg_color=Color(col,fill_a); s.border_color=col; s.set_border_width_all(2); s.set_corner_radius_all(6)
	s.content_margin_left=18; s.content_margin_right=18; s.content_margin_top=8; s.content_margin_bottom=8; return s

static func button(text:String,cb:Callable,col:=Color("#b45cff"))->Button:
	var b:=Button.new(); b.text=text; b.add_theme_font_size_override("font_size",22)
	b.add_theme_stylebox_override("normal",style(col,.25)); b.add_theme_stylebox_override("hover",style(col,.5))
	b.add_theme_stylebox_override("pressed",style(col,.7)); b.add_theme_stylebox_override("focus",style(Color("#ffd23c"),.45))
	b.pressed.connect(func(): Sfx.play("ui",-4.0); cb.call()); return b

static func vbox(parent:Control,sep:=10)->VBoxContainer:
	var v:=VBoxContainer.new(); v.alignment=BoxContainer.ALIGNMENT_CENTER; v.add_theme_constant_override("separation",sep)
	v.set_anchors_preset(Control.PRESET_FULL_RECT); parent.add_child(v); return v

static func center(c:Control)->CenterContainer:
	var cc:=CenterContainer.new(); cc.add_child(c); return cc
