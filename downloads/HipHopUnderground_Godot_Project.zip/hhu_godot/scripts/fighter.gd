class_name Fighter
extends CharacterBody3D
## One fighter: model + AnimationTree (state machine for locomotion, OneShot for actions),
## Area3D hurtbox + per-limb hitboxes, and all simulation state (frame-data in 60 Hz ticks,
## positions in "stage pixels": x 0..960, ground y=500, like the web version).
const PX:=0.0061
const LIB:="res://anim/fight_lib.res"
const LOOPS:={"idle":"Punch_Enter","walk":"Walk","block":"Crouch_Idle","jump":"Jump","down":"Death01","held":"Held","hold":"Grab_Hold","tumble":"Tumble","launched":"Launched","win":"Dance","relax":"Idle"}
var d:Dictionary
var idx:=0
var model:Node3D
var skel:Skeleton3D
var tree:AnimationTree
var sm_play:AnimationNodeStateMachinePlayback
var act_anim:AnimationNodeAnimation
var rise_anim:AnimationNodeAnimation
var flinch:SkeletonModifier3D
var hurt:Area3D
var hit_areas:={}
var bone_ids:={}
var col:Color
var aura:OmniLight3D
var cur_loco:=""
# ---- sim state ----
var x:=0.0; var y:=500.0; var vx:=0.0; var vy:=0.0; var face:=1; var yaw:=PI/2
var hp:=100.0; var maxhp:=100.0; var hype:=0.0; var mode:=0; var wins:=0
var st:="idle"; var t:=0.0; var mv={}; var hit:=false; var hits:=0; var last_hit_t:=-99.0
var stun:=0; var buf:=""; var buf_t:=0; var queue:Array=[]; var seq_t:Array=[]; var seq_m:Array=[]; var chain_n:=0
var air:=false; var landed:=0; var down_t:=0; var jug:=0; var spin:=0.0; var rz:=0.0; var zoff:=0.0; var walled:=false
var hold_n:=0; var strike_t:=0; var mash:=0; var thr={}; var impacted:=false; var stomped:=false; var pending_dmg:=0.0; var pending_by:Fighter
var combo:=0; var combo_t:=0; var flash:=0; var ct:=false; var flip_t:=0; var jump_t:=0; var land_t:=0; var light_hurt:=false
var ai_t:=0.0; var ai_hold:={}; var passive:=false; var step_acc:=0.0

func setup(def:Dictionary,i:int)->void:
	d=def; idx=i; col=Color(d.col)
	collision_layer=0; collision_mask=0
	var cs:=CollisionShape3D.new(); var cap:=CapsuleShape3D.new(); cap.radius=.3; cap.height=1.8; cs.shape=cap; cs.position.y=.9; add_child(cs)
	model=load("res://fighters/%s.glb"%d.id).instantiate()
	add_child(model)
	model.scale=Vector3(d.scale[0],d.scale[1],d.scale[2])
	skel=model.find_child("Skeleton3D",true,false)
	for m in model.find_children("*","MeshInstance3D",true,false):
		var mi:=m as MeshInstance3D; mi.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		for si in mi.mesh.get_surface_count():
			var sm:=mi.mesh.surface_get_material(si)
			var nm:StandardMaterial3D=(sm.duplicate() if sm is StandardMaterial3D else StandardMaterial3D.new())
			nm.vertex_color_use_as_albedo=true; nm.albedo_color=Color.WHITE; nm.roughness=.62; nm.metallic=0.0
			nm.rim_enabled=true; nm.rim=.35; nm.rim_tint=.6
			mi.set_surface_override_material(si,nm)
	_build_tree()
	flinch=preload("res://scripts/flinch.gd").new(); skel.add_child(flinch); flinch.setup(skel)
	# hurtbox (layer 3) + hitboxes (layer 2)
	hurt=Area3D.new(); hurt.collision_layer=4; hurt.collision_mask=0; hurt.monitorable=true; hurt.monitoring=false
	var hs:=CollisionShape3D.new(); var hc:=CapsuleShape3D.new(); hc.radius=.32; hc.height=1.75*d.scale[1]; hs.shape=hc; hs.position.y=.92*d.scale[1]; hurt.add_child(hs); add_child(hurt)
	for b in ["DEF-hand.L","DEF-hand.R","DEF-foot.L","DEF-foot.R","DEF-head","DEF-spine.002","DEF-shin.L","DEF-forearm.L","DEF-forearm.R","DEF-shin.R"]:
		bone_ids[b]=skel.find_bone(b)
	for b in ["DEF-hand.L","DEF-hand.R","DEF-foot.L","DEF-foot.R"]:
		var a:=Area3D.new(); a.collision_layer=2; a.collision_mask=4; a.monitoring=true; a.monitorable=false; a.top_level=true
		var s:=CollisionShape3D.new(); var sp:=SphereShape3D.new(); sp.radius=.2; s.shape=sp; a.add_child(s); add_child(a); hit_areas[b]=a
	aura=OmniLight3D.new(); aura.light_color=col; aura.light_energy=0; aura.omni_range=3.5; aura.position=Vector3(0,1.2,.6); add_child(aura)

func _build_tree()->void:
	tree=AnimationTree.new()
	tree.add_animation_library("",load(LIB))
	model.add_child(tree)
	tree.root_node=NodePath("..")
	tree.callback_mode_process=AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
	var bt:=AnimationNodeBlendTree.new()
	var sm:=AnimationNodeStateMachine.new()
	var names:=LOOPS.keys()
	for k in names:
		var an:=AnimationNodeAnimation.new(); an.animation=LOOPS[k]; sm.add_node(k,an)
	for a in names:
		for b in names:
			if a!=b:
				var tr:=AnimationNodeStateMachineTransition.new(); tr.xfade_time=0.14; sm.add_transition(a,b,tr)
	var st0:=AnimationNodeStateMachineTransition.new(); sm.add_transition("Start","idle",st0)
	bt.add_node("sm",sm); var lts:=AnimationNodeTimeScale.new(); bt.add_node("loco_ts",lts)
	var one:=AnimationNodeOneShot.new(); one.fadein_time=.06; one.fadeout_time=.12; bt.add_node("act",one)
	act_anim=AnimationNodeAnimation.new(); act_anim.animation="Punch_Jab"; bt.add_node("act_anim",act_anim)
	bt.add_node("act_ts",AnimationNodeTimeScale.new())
	var rone:=AnimationNodeOneShot.new(); rone.fadein_time=.1; rone.fadeout_time=.15; bt.add_node("rise",rone)
	rise_anim=AnimationNodeAnimation.new(); rise_anim.animation="Death01"; rise_anim.play_mode=AnimationNodeAnimation.PLAY_MODE_BACKWARD; bt.add_node("rise_anim",rise_anim)
	bt.add_node("rise_ts",AnimationNodeTimeScale.new())
	bt.connect_node("loco_ts",0,"sm"); bt.connect_node("act",0,"loco_ts")
	bt.connect_node("act_ts",0,"act_anim"); bt.connect_node("act",1,"act_ts")
	bt.connect_node("rise",0,"act"); bt.connect_node("rise_ts",0,"rise_anim"); bt.connect_node("rise",1,"rise_ts")
	bt.connect_node("output",0,"rise")
	tree.tree_root=bt; tree.active=true
	sm_play=tree.get("parameters/sm/playback")
	loco("idle")

func clip_len(n:String)->float:
	var a:=tree.get_animation(n)
	return a.length if a else 1.0

func loco(state:String,ts:=1.0)->void:
	tree.set("parameters/loco_ts/scale",ts)
	if state==cur_loco: return
	cur_loco=state
	if sm_play: sm_play.travel(state)

## play a one-shot action clip (attack, hit reaction, throw...) at time scale ts
func action(clip:String,ts:=1.0,fade:=.07)->void:
	act_anim.animation=clip
	(tree.tree_root as AnimationNodeBlendTree).get_node("act").fadein_time=fade
	tree.set("parameters/act_ts/scale",ts)
	tree.set("parameters/act/request",AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)
func stop_action()->void:
	if tree.get("parameters/act/active"): tree.set("parameters/act/request",AnimationNodeOneShot.ONE_SHOT_REQUEST_FADE_OUT)
func rise_anim_play(dur:float)->void:
	tree.set("parameters/rise_ts/scale",clip_len("Death01")/dur)
	tree.set("parameters/rise/request",AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)
func action_active()->bool: return tree.get("parameters/act/active")

func bone_pos(b:String)->Vector3:
	var i:int=bone_ids.get(b,-1)
	if i<0: return global_position+Vector3(0,1.3,0)
	return skel.global_transform*skel.get_bone_global_pose(i).origin

## advance visuals: transform from sim state, animation, boxes
func sync_visual(dt:float,anim_scale:float)->void:
	var a:=rz
	var p:=Vector3((x-480.0)*PX,(500.0-y)*PX,zoff)
	if a!=0.0: p+=Vector3(sin(a)*.95,(1.0-cos(a))*.95,0)
	global_position=p
	var ty:=PI/2 if face>0 else -PI/2
	var dd:=ty-yaw
	yaw=ty if absf(dd)<.02 else yaw+dd*minf(1.0,dt*18.0)
	rotation=Vector3(0,0,0)
	model.rotation=Vector3(0,yaw,0)
	rotation.z=a
	flinch.calm=st in ["idle","walk","block"]
	flinch.step(dt)
	tree.advance(dt*anim_scale)
	for b in hit_areas: hit_areas[b].global_position=bone_pos(b)
	aura.light_energy=lerpf(aura.light_energy,(2.5+sin(Time.get_ticks_msec()*.008)) if mode>0 else 0.0,.2)
