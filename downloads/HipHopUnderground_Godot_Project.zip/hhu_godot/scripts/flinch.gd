extends SkeletonModifier3D
## Additive procedural layer applied after the AnimationTree: hit flinch spring (head/body/leg),
## breathing and a subtle weight shift. Keeps clips intact instead of fully overriding them.
var amp:=0.0
var vel:=0.0
var zone:="head"
var t:=0.0
var calm:=true
var b_neck:=-1; var b_head:=-1; var b_sp1:=-1; var b_sp3:=-1; var b_hips:=-1; var b_thigh:=-1
func setup(sk:Skeleton3D)->void:
	b_neck=sk.find_bone("DEF-neck"); b_head=sk.find_bone("DEF-head"); b_sp1=sk.find_bone("DEF-spine.001")
	b_sp3=sk.find_bone("DEF-spine.003"); b_hips=sk.find_bone("DEF-hips"); b_thigh=sk.find_bone("DEF-thigh.L")
func kick(z:String,a:float)->void:
	zone=z; vel+=a
func step(dt:float)->void:
	t+=dt
	var k:=minf(dt,0.05)*60.0
	vel+=(-amp*0.28)*k; vel*=pow(0.72,k); amp+=vel*k*0.5
func _rot(sk:Skeleton3D,b:int,e:Vector3)->void:
	if b<0: return
	sk.set_bone_pose_rotation(b,sk.get_bone_pose_rotation(b)*Quaternion.from_euler(e))
func _process_modification()->void:
	var sk:=get_skeleton()
	if sk==null: return
	_rot(sk,b_sp3,Vector3(sin(t*2.1)*0.025,0,0))   # breathing
	if calm: _rot(sk,b_hips,Vector3(0,sin(t*0.9)*0.03,sin(t*0.9)*0.02))  # weight shift
	var x:=amp
	if absf(x)<0.002: return
	match zone:
		"head":
			_rot(sk,b_neck,Vector3(-x*0.5,x*0.15,0)); _rot(sk,b_head,Vector3(-x*0.9,x*0.3,x*0.15)); _rot(sk,b_sp3,Vector3(-x*0.25,0,0))
		"body":
			_rot(sk,b_sp1,Vector3(x*0.45,0,0)); _rot(sk,b_sp3,Vector3(x*0.35,0,0)); _rot(sk,b_head,Vector3(x*0.2,0,0))
		_:
			_rot(sk,b_sp1,Vector3(0,0,x*0.25)); _rot(sk,b_thigh,Vector3(-x*0.3,0,0))
