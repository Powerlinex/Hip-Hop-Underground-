extends Control
## Character select: 16 cards (8x2), P1 (and P2 in versus-human) pick; locked cards greyed.
var cards:Array[Button]=[]
var cursor:=[0,1]
var done:=[false,false]
var info:Label
var who:Label
func _ready()->void:
	Sfx.music("menu")
	UI.bg(self,.6)
	var v:=UI.vbox(self,10)
	v.add_child(UI.label("CHOOSE YOUR FIGHTER",44,Color("#ffd23c")))
	who=UI.label("P1 PICK",20,Color("#c9a7ff")); v.add_child(who)
	var g:=GridContainer.new(); g.columns=8; g.add_theme_constant_override("h_separation",8); g.add_theme_constant_override("v_separation",8)
	for i in Game.ROSTER.size():
		var d:Dictionary=Game.ROSTER[i]; var b:=Button.new(); b.custom_minimum_size=Vector2(132,150)
		b.icon=load("res://art/portraits/%s.jpg"%d.id); b.expand_icon=true; b.icon_alignment=HORIZONTAL_ALIGNMENT_CENTER; b.vertical_icon_alignment=VERTICAL_ALIGNMENT_TOP
		b.text=d.name if Game.is_unlocked(d.id) else "LOCKED"; b.add_theme_font_size_override("font_size",11)
		var col:=Color(d.col); b.add_theme_stylebox_override("normal",UI.style(col,.15)); b.add_theme_stylebox_override("hover",UI.style(col,.45)); b.add_theme_stylebox_override("focus",UI.style(Color("#ffd23c"),.5))
		if not Game.is_unlocked(d.id): b.modulate=Color(.35,.35,.4)
		b.pressed.connect(_pick.bind(i)); b.focus_entered.connect(_hover.bind(i)); b.mouse_entered.connect(_hover.bind(i))
		g.add_child(b); cards.append(b)
	v.add_child(UI.center(g))
	info=UI.label("",18,Color.WHITE); info.autowrap_mode=TextServer.AUTOWRAP_WORD; info.custom_minimum_size=Vector2(900,60); v.add_child(UI.center(info))
	v.add_child(UI.center(UI.button("BACK",func(): Game.goto("MainMenu"))))
	cards[0].grab_focus(); _hover(0)
	if Game.autotest=="shots":
		await get_tree().create_timer(1.0).timeout
		Shots.shot("select_full")
		await get_tree().create_timer(.3).timeout
		Game.pick=[0,3]; Game.goto("Fight")
func _hover(i:int)->void:
	var d:Dictionary=Game.ROSTER[i]
	if not Game.is_unlocked(d.id): info.text="LOCKED — clear Story chapters to unlock "+d.name; return
	var s:Array=[]
	for st in d.strings: s.append(st.n+" ("+" ".join(st.seq).to_upper()+")")
	info.text="%s · %s\n%s: %s · Throw: %s · Strings: %s"%[d.name,d.tag,d.mode,d.moves.sp,Game.THROWS[d.throw].n,", ".join(s)]
func _pick(i:int)->void:
	if not Game.is_unlocked(Game.ROSTER[i].id): Sfx.play("block"); return
	var p:=0 if not done[0] else 1
	done[p]=true; Game.pick[p]=i; Sfx.play("uiok"); Sfx.say("n_"+Game.ROSTER[i].id)
	if Game.story.on:
		Game.story.pi=i; await get_tree().create_timer(.8).timeout; Game.goto("Fight"); return
	if p==0 and Game.vs_cpu:
		var o:=randi()%Game.ROSTER.size()
		while o==i or not Game.is_unlocked(Game.ROSTER[o].id): o=randi()%Game.ROSTER.size()
		Game.pick[1]=o; done[1]=true
	if p==0 and not Game.vs_cpu: who.text="P2 PICK"; return
	await get_tree().create_timer(1.0).timeout
	Game.goto("Fight")
