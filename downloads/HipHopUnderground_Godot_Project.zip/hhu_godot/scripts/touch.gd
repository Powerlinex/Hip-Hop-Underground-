extends CanvasLayer
## On-screen touch controls: left virtual joystick + right action buttons.
## Hidden until the device has a touchscreen or a touch happens (or --touch arg).
const BTNS:=[ # label, action, offset from bottom-right, radius, color
	["PUNCH","p1_lp",Vector2(-250,-110),52,Color(0.2,0.8,1)],
	["HEAVY","p1_hp",Vector2(-130,-170),52,Color(1,0.3,0.6)],
	["GRAB","p1_gr",Vector2(-120,-300),46,Color(1,0.8,0.2)],
	["BLOCK","p1_down",Vector2(-370,-80),44,Color(0.6,0.6,0.7)],
	["COUNTER","p1_ct",Vector2(-250,-250),44,Color(0.5,1,0.5)],
	["POWER","p1_sp",Vector2(-380,-210),48,Color(0.85,0.4,1)],
]
var active:=false
var stick_touch:=-1; var stick_center:=Vector2.ZERO; var stick_vec:=Vector2.ZERO
var btn_touch:={}  # touch index -> action
var dirs:={"p1_left":false,"p1_right":false,"p1_up":false,"p1_down_stick":false}
var root:Control
const STICK_R:=90.0
func _ready()->void:
	layer=100; process_mode=Node.PROCESS_MODE_ALWAYS
	root=Control.new(); root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter=Control.MOUSE_FILTER_IGNORE; add_child(root); root.draw.connect(_draw_ui)
	active=DisplayServer.is_touchscreen_available() or "--touch" in OS.get_cmdline_user_args()
	root.visible=active
func _vp()->Vector2: return root.get_viewport_rect().size
func _stick_home()->Vector2: return Vector2(170,_vp().y-170)
func _btn_pos(b)->Vector2: return _vp()+b[2]
func _pause_pos()->Vector2: return Vector2(_vp().x*0.5,46)
func _in_game()->bool:
	var s:=get_tree().current_scene
	return s!=null and s.scene_file_path.get_file().get_basename().to_lower() in ["fight"]
func _input(e:InputEvent)->void:
	if e is InputEventScreenTouch:
		if not active: active=true; root.visible=true
		if e.pressed: _press(e.index,e.position)
		else: _release(e.index)
		root.queue_redraw()
	elif e is InputEventScreenDrag and e.index==stick_touch:
		_stick(e.position); root.queue_redraw()
func _press(i:int,p:Vector2)->void:
	for b in BTNS:
		if p.distance_to(_btn_pos(b))<=b[3]*1.15:
			btn_touch[i]=b[1]; Input.action_press(b[1])
			if b[1]=="p1_lp": Input.action_press("ui_accept")
			get_viewport().set_input_as_handled(); return
	if p.x<_vp().x*0.4 and p.y>_vp().y*0.35 and stick_touch<0 and _in_game():
		stick_touch=i; stick_center=p; _stick(p); get_viewport().set_input_as_handled()
func _release(i:int)->void:
	if i==stick_touch:
		stick_touch=-1; _stick(stick_center)
	if btn_touch.has(i):
		var a:String=btn_touch[i]; btn_touch.erase(i)
		if not a in btn_touch.values(): Input.action_release(a)
		if a=="p1_lp": Input.action_release("ui_accept")
func _stick(p:Vector2)->void:
	stick_vec=(p-stick_center).limit_length(STICK_R)/STICK_R
	_setdir("p1_left",stick_vec.x<-0.35,"ui_left"); _setdir("p1_right",stick_vec.x>0.35,"ui_right")
	_setdir("p1_up",stick_vec.y<-0.5,"ui_up"); _setdir("p1_down_stick",stick_vec.y>0.5,"ui_down")
func _setdir(k:String,on:bool,ui:String)->void:
	if dirs[k]==on: return
	dirs[k]=on; var act:=k.replace("_stick","")
	if on: Input.action_press(act); Input.action_press(ui)
	else:
		if not act in btn_touch.values(): Input.action_release(act)
		Input.action_release(ui)
func _process(_d:float)->void:
	if active: root.queue_redraw()
func _draw_ui()->void:
	if not active: return
	var f:=ThemeDB.fallback_font
	var game:=_in_game()
	if game:
		var c:=stick_center if stick_touch>=0 else _stick_home()
		root.draw_circle(c,STICK_R,Color(1,1,1,0.12)); root.draw_arc(c,STICK_R,0,TAU,48,Color(1,1,1,0.4),3)
		root.draw_circle(c+stick_vec*STICK_R,40,Color(1,1,1,0.35))
	for b in BTNS:
		if not game and b[1]!="p1_lp": continue
		var p:=_btn_pos(b); var down:bool=b[1] in btn_touch.values()
		var col:Color=b[4]; col.a=0.55 if down else 0.28
		root.draw_circle(p,b[3],col); root.draw_arc(p,b[3],0,TAU,40,Color(1,1,1,0.55),2)
		var lbl:String=b[0] if game else "OK"
		var w:=f.get_string_size(lbl,HORIZONTAL_ALIGNMENT_LEFT,-1,15).x
		root.draw_string(f,p+Vector2(-w/2,6),lbl,HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color(1,1,1,0.85))
