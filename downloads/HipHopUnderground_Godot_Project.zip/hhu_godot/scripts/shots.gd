extends Node
## Screenshot helper (only works with a real renderer, e.g. under xvfb).
var out_dir:="res://../shots/"
func shot(name:String)->void:
	if DisplayServer.get_name()=="headless": return
	await RenderingServer.frame_post_draw
	var img:=get_viewport().get_texture().get_image()
	var d:=ProjectSettings.globalize_path("res://").path_join("../hhu_godot_shots")
	DirAccess.make_dir_recursive_absolute(d)
	img.save_png(d.path_join(name+".png")); Game.log_line("shot "+name)
