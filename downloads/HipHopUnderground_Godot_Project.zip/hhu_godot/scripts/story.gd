extends Control
## Story mode: season ladder (3 seasons), corner pick for season 3, progress + unlocks in user://save.cfg
var box:VBoxContainer
func _ready()->void:
	Sfx.music("story")
	UI.bg(self,.65)
	box=UI.vbox(self,12)
	_list()
	if Game.autotest=="story":
		await get_tree().create_timer(.5).timeout
		_begin(0)
func _clear()->void:
	for c in box.get_children(): c.queue_free()
func _list()->void:
	_clear()
	box.add_child(UI.label("STORY · SEASONS",52,Color("#ffd23c")))
	for i in Game.SEASONS.size():
		var S:Dictionary=Game.SEASONS[i]; var prog:=Game.season_progress(S.id)
		var unl:bool=i==0 or Game.season_progress(Game.SEASONS[i-1].id)>=Game.SEASONS[i-1].ch.size()
		var txt:String="%s\n%s"%[S.title, ("Chapter %d/%d%s"%[min(prog+1,S.ch.size()),S.ch.size()," · COMPLETE" if prog>=S.ch.size() else ""]) if unl else "LOCKED · finish the previous season"]
		var b:=UI.button(txt,_begin.bind(i),Color("#b45cff") if unl else Color("#555566"))
		b.custom_minimum_size=Vector2(760,70); b.disabled=not unl; b.tooltip_text=S.blurb
		box.add_child(UI.center(b))
	var n:=0
	for d in Game.ROSTER: n+=int(Game.is_unlocked(d.id))
	box.add_child(UI.label("Unlocked fighters: %d / %d"%[n,Game.ROSTER.size()],18,Color("#c9a7ff")))
	box.add_child(UI.center(UI.button("BACK",func(): Game.goto("MainMenu"))))
func _begin(i:int)->void:
	var S:Dictionary=Game.SEASONS[i]
	Game.story={"on":true,"si":i,"ch":Game.season_progress(S.id)%S.ch.size(),"pi":0,"rival":""}
	if S.has("corner"):
		_clear(); box.add_child(UI.label("PICK A CORNER",44,Color("#ffd23c")))
		for id in ["psalm","dutch"]:
			var d:Dictionary=Game.ROSTER[Game.ri(id)]; var riv:="dutch" if id=="psalm" else "psalm"
			box.add_child(UI.center(UI.button(d.name+"'S CORNER — rival: "+Game.ROSTER[Game.ri(riv)].name,func(): Game.story.pi=Game.ri(id); Game.story.rival=riv; _play(),Color(d.col))))
		return
	if Game.autotest=="story":
		Game.story.pi=0; _play(); return
	Game.goto("Select")   # select.gd sees Game.story.on and starts the chapter
func _play()->void:
	Game.goto("Fight")
