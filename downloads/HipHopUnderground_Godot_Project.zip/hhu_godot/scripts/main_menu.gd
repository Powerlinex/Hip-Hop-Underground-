extends Control
func _ready()->void:
	Sfx.music("menu"); Sfx.crowd(false)
	UI.bg(self,.45)
	var v:=UI.vbox(self,14)
	v.add_child(UI.label("HIP HOP",76,Color("#e8e8ff")))
	v.add_child(UI.label("UNDERGROUND",76,Color("#ffd23c")))
	v.add_child(UI.label("GODOT EDITION · NEON YARD",20,Color("#c9a7ff")))
	var b1:=UI.button("STORY · SEASONS",func(): Game.goto("Story"),Color("#ffd23c"))
	v.add_child(UI.center(b1))
	v.add_child(UI.center(UI.button("VERSUS",func(): Game.story={"on":false}; Game.rules={}; Game.goto("Select"))))
	var opp:=UI.button("OPPONENT: CPU",func(): pass)
	opp.pressed.connect(func(): Game.vs_cpu=not Game.vs_cpu; opp.text="OPPONENT: "+("CPU" if Game.vs_cpu else "2 PLAYERS"))
	v.add_child(UI.center(opp))
	v.add_child(UI.center(UI.button("SETTINGS",func(): Game.goto("Settings"))))
	v.add_child(UI.center(UI.button("QUIT",func(): get_tree().quit(),Color("#ff5c8a"))))
	v.add_child(UI.label("P1: A/D move · W jump · S block/crouch · J light · K heavy · L grab · I counter · U Mode/special · gamepad supported",14,Color("#bbbbdd")))
	b1.grab_focus()
	if Game.autotest=="match":
		Game.auto_both=true; Game.pick=Game.test_pick; Game.rules={"cpuHp":Game.test_hp}; Game.goto("Fight")
	elif Game.autotest=="story":
		Game.auto_both=true; Game.reset_save(); Game.goto("Story")
	elif Game.autotest=="shots":
		Game.auto_both=true; Game.rules={"cpuHp":0.6}; Game.goto("Select")
