class_name FX
extends Node3D
## Pooled GPUParticles3D bursts: sparks, coloured impact, sweat/spit, dust, block sparks, plus rain.
var pools:={}
var idx:={}
static func _mat(col:Color,additive:=true)->StandardMaterial3D:
	var m:=StandardMaterial3D.new(); m.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; m.blend_mode=BaseMaterial3D.BLEND_MODE_ADD if additive else BaseMaterial3D.BLEND_MODE_MIX
	m.billboard_mode=BaseMaterial3D.BILLBOARD_PARTICLES; m.vertex_color_use_as_albedo=true; m.albedo_color=col
	var g:=Gradient.new(); g.set_color(0,Color(1,1,1,1)); g.set_color(1,Color(1,1,1,0))
	var gt:=GradientTexture2D.new(); gt.gradient=g; gt.fill=GradientTexture2D.FILL_RADIAL; gt.fill_from=Vector2(.5,.5); gt.fill_to=Vector2(1,.5); gt.width=32; gt.height=32
	m.albedo_texture=gt; return m
func _emitter(amount:int,life:float,speed:Vector2,grav:float,size:float,col:Color,spread:=180.0,additive:=true,damp:=2.0,stretch:=1.0)->GPUParticles3D:
	var p:=GPUParticles3D.new(); p.one_shot=true; p.emitting=false; p.amount=amount; p.lifetime=life; p.explosiveness=1.0; p.local_coords=false
	var pm:=ParticleProcessMaterial.new(); pm.direction=Vector3(0,1,0); pm.spread=spread; pm.initial_velocity_min=speed.x; pm.initial_velocity_max=speed.y
	pm.gravity=Vector3(0,-grav,0); pm.damping_min=damp; pm.damping_max=damp*1.5; pm.scale_min=.5; pm.scale_max=1.2
	var cr:=Curve.new(); cr.add_point(Vector2(0,1)); cr.add_point(Vector2(1,0)); var ct:=CurveTexture.new(); ct.curve=cr; pm.scale_curve=ct
	pm.color=col; p.process_material=pm
	var q:=QuadMesh.new(); q.size=Vector2(size,size*stretch); q.material=_mat(Color.WHITE,additive); p.draw_pass_1=q
	p.visibility_aabb=AABB(Vector3(-4,-4,-4),Vector3(8,8,8)); add_child(p); return p
func _ready()->void:
	_pool("spark",6,func(): return _emitter(28,.35,Vector2(3,7),4.0,.06,Color(1,.95,.75),180,true,3.0))
	_pool("impact",6,func(): return _emitter(18,.45,Vector2(1.5,4),2.0,.12,Color.WHITE,180,true,2.5))
	_pool("flash",6,func(): return _emitter(1,.14,Vector2(0,0),0,.9,Color(1,.95,.85),0,true,0))
	_pool("sweat",4,func(): return _emitter(14,.8,Vector2(1,2.6),6.0,.05,Color(.75,.9,1,.9),50,false,.5))
	_pool("dust",4,func(): return _emitter(36,1.1,Vector2(.6,2.2),-.3,.35,Color(.55,.5,.62,.55),80,false,2.0))
	_pool("block",4,func(): return _emitter(20,.3,Vector2(2,5),3.0,.05,Color(.5,.85,1),120,true,3.0))
	_pool("aura",4,func(): return _emitter(60,.9,Vector2(1,4),-1.0,.14,Color.WHITE,180,true,1.0))
func _pool(n:String,c:int,mk:Callable)->void:
	pools[n]=[]; idx[n]=0
	for i in c: pools[n].append(mk.call())
func emit(n:String,pos:Vector3,col:=Color(1,1,1,1),dir:=Vector3.UP)->void:
	var arr:Array=pools[n]; var p:GPUParticles3D=arr[idx[n]%arr.size()]; idx[n]+=1
	p.global_position=pos
	var pm:ParticleProcessMaterial=p.process_material
	if col!=Color(1,1,1,1): pm.color=col
	pm.direction=dir
	p.restart(); p.emitting=true
static func rain(parent:Node3D,amount:int)->GPUParticles3D:
	var p:=GPUParticles3D.new(); p.amount=amount; p.lifetime=1.1; p.preprocess=1.0; p.local_coords=false
	var pm:=ParticleProcessMaterial.new(); pm.emission_shape=ParticleProcessMaterial.EMISSION_SHAPE_BOX; pm.emission_box_extents=Vector3(9,0.2,4)
	pm.direction=Vector3(0.05,-1,0); pm.spread=2; pm.initial_velocity_min=11; pm.initial_velocity_max=14; pm.gravity=Vector3(0,-4,0); pm.color=Color(.7,.75,1,.45)
	p.process_material=pm
	var q:=QuadMesh.new(); q.size=Vector2(.012,.35); var m:=StandardMaterial3D.new(); m.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; m.blend_mode=BaseMaterial3D.BLEND_MODE_ADD; m.billboard_mode=BaseMaterial3D.BILLBOARD_FIXED_Y; m.vertex_color_use_as_albedo=true
	q.material=m; p.draw_pass_1=q; p.position=Vector3(0,8,-1); p.visibility_aabb=AABB(Vector3(-10,-10,-5),Vector3(20,12,10))
	parent.add_child(p); return p
