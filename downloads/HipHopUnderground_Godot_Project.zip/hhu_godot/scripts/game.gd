extends Node
## Global game state: data tables, save/unlocks, settings, input map, scene flow.
const SAVE_PATH:="user://save.cfg"
const SETTINGS_PATH:="user://settings.cfg"
var DATA:Dictionary={}
var ROSTER:Array=[]
var MV:Dictionary={}
var UNI:Array=[]
var SPV:Dictionary={}
var THROWS:Dictionary={}
var SEASONS:Array=[]
var pick:=[0,1]
var vs_cpu:=true
var rules:Dictionary={}
var story:Dictionary={"on":false}
var save:=ConfigFile.new()
var settings:=ConfigFile.new()
var autotest:=""          # "", "match", "story", "shots"
var auto_both:=false      # CPU vs CPU
var quality_high:=false
var log_lines:PackedStringArray=[]
var test_pick:=[0,3]
var test_hp:=0.45

func _ready()->void:
	var f:=FileAccess.open("res://data/game.json",FileAccess.READ)
	DATA=JSON.parse_string(f.get_as_text())
	ROSTER=DATA.ROSTER; MV=DATA.MV; UNI=DATA.UNI; SPV=DATA.SPV; THROWS=DATA.THROWS; SEASONS=DATA.SEASONS
	save.load(SAVE_PATH)
	settings.load(SETTINGS_PATH)
	quality_high=RenderingServer.get_current_rendering_method()=="forward_plus"
	_setup_input()
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--autotest="): autotest=a.split("=")[1]
		if a.begins_with("--pick="): test_pick=[int(a.split("=")[1].split(",")[0]),int(a.split("=")[1].split(",")[1])]
		if a.begins_with("--cpuhp="): test_hp=float(a.split("=")[1])
	if autotest!="": log_line("AUTOTEST "+autotest+" renderer="+RenderingServer.get_current_rendering_method())

func log_line(s:String)->void:
	print("[HHU] ",s); log_lines.append(s)

func ri(id:String)->int:
	for i in ROSTER.size():
		if ROSTER[i].id==id: return i
	return 0

# ---------- unlocks ----------
const START_UNLOCKED:=["psalm","dutch","north","boss","jet","duchess"]
func is_unlocked(id:String)->bool:
	return id in START_UNLOCKED or save.get_value("unlocks",id,false)
func unlock(id:String)->bool:
	if is_unlocked(id): return false
	save.set_value("unlocks",id,true); save.save(SAVE_PATH); return true
func season_progress(sid:String)->int: return save.get_value("seasons",sid,0)
func set_season_progress(sid:String,v:int)->void:
	save.set_value("seasons",sid,v); save.save(SAVE_PATH)
func unlock_all()->void:
	for d in ROSTER: unlock(d.id)
func reset_save()->void:
	save=ConfigFile.new(); save.save(SAVE_PATH)

# ---------- settings ----------
func get_setting(k:String,def):
	return settings.get_value("audio",k,def)
func set_setting(k:String,v)->void:
	settings.set_value("audio",k,v); settings.save(SETTINGS_PATH)

# ---------- scenes ----------
func goto(scene:String)->void:
	get_tree().call_deferred("change_scene_to_file","res://scenes/"+scene+".tscn")

# ---------- input map (keyboard + gamepad) ----------
func _key(action:String,keys:Array,joy_buttons:Array=[],axis:=-1,axis_dir:=0.0)->void:
	if not InputMap.has_action(action): InputMap.add_action(action,0.4)
	for k in keys:
		var e:=InputEventKey.new(); e.physical_keycode=k; InputMap.action_add_event(action,e)
	for b in joy_buttons:
		var j:=InputEventJoypadButton.new(); j.button_index=b; j.device=-1; InputMap.action_add_event(action,j)
	if axis>=0:
		var m:=InputEventJoypadMotion.new(); m.axis=axis; m.axis_value=axis_dir; m.device=-1; InputMap.action_add_event(action,m)
func _setup_input()->void:
	_key("p1_left",[KEY_A],[JOY_BUTTON_DPAD_LEFT],JOY_AXIS_LEFT_X,-1.0)
	_key("p1_right",[KEY_D],[JOY_BUTTON_DPAD_RIGHT],JOY_AXIS_LEFT_X,1.0)
	_key("p1_up",[KEY_W],[JOY_BUTTON_DPAD_UP],JOY_AXIS_LEFT_Y,-1.0)
	_key("p1_down",[KEY_S],[JOY_BUTTON_DPAD_DOWN],JOY_AXIS_LEFT_Y,1.0)
	_key("p1_lp",[KEY_J],[JOY_BUTTON_X])
	_key("p1_hp",[KEY_K],[JOY_BUTTON_Y])
	_key("p1_gr",[KEY_L],[JOY_BUTTON_B])
	_key("p1_ct",[KEY_I],[JOY_BUTTON_RIGHT_SHOULDER])
	_key("p1_sp",[KEY_U],[JOY_BUTTON_LEFT_SHOULDER])
	_key("p2_left",[KEY_LEFT]); _key("p2_right",[KEY_RIGHT]); _key("p2_up",[KEY_UP]); _key("p2_down",[KEY_DOWN])
	_key("p2_lp",[KEY_KP_1]); _key("p2_hp",[KEY_KP_2]); _key("p2_gr",[KEY_KP_3]); _key("p2_ct",[KEY_KP_5]); _key("p2_sp",[KEY_KP_4])
	_key("ui_pause",[KEY_ESCAPE],[JOY_BUTTON_START])
