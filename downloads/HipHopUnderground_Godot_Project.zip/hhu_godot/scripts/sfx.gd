extends Node
## Audio: buses Master/Music/SFX/Announcer/Crowd, pooled one-shot players, music + crowd loops, announcer.
const BUSES:=["Music","SFX","Announcer","Crowd"]
var pool:Array[AudioStreamPlayer]=[]
var music_player:AudioStreamPlayer
var crowd_player:AudioStreamPlayer
var vo_player:AudioStreamPlayer
var cache:={}
var cur_music:=""
var count:=0

func _ready()->void:
	for b in BUSES:
		if AudioServer.get_bus_index(b)<0:
			AudioServer.add_bus(); var i:=AudioServer.bus_count-1; AudioServer.set_bus_name(i,b); AudioServer.set_bus_send(i,"Master")
	var rv:=AudioEffectReverb.new(); rv.room_size=.35; rv.wet=.12; rv.dry=1.0
	AudioServer.add_bus_effect(AudioServer.get_bus_index("SFX"),rv)
	var lim:=AudioEffectLimiter.new(); AudioServer.add_bus_effect(0,lim)
	for i in 14:
		var p:=AudioStreamPlayer.new(); p.bus="SFX"; add_child(p); pool.append(p)
	music_player=AudioStreamPlayer.new(); music_player.bus="Music"; add_child(music_player)
	crowd_player=AudioStreamPlayer.new(); crowd_player.bus="Crowd"; add_child(crowd_player)
	vo_player=AudioStreamPlayer.new(); vo_player.bus="Announcer"; add_child(vo_player)
	apply_volumes()

func apply_volumes()->void:
	var mute:bool=Game.get_setting("mute",false)
	AudioServer.set_bus_mute(0,mute)
	AudioServer.set_bus_volume_db(0,linear_to_db(Game.get_setting("Master",0.8)))
	for b in BUSES:
		AudioServer.set_bus_volume_db(AudioServer.get_bus_index(b),linear_to_db(max(0.0001,Game.get_setting(b,{"Music":.55,"SFX":.9,"Announcer":1.0,"Crowd":.5}[b]))))

func _load_stream(path:String)->AudioStream:
	if cache.has(path): return cache[path]
	var s:AudioStream=null
	if ResourceLoader.exists(path): s=load(path)
	cache[path]=s; return s

## name like "punch_heavy_face" (variants _0.._2 picked automatically), "block", "sting_psalm"
func play(name:String,vol_db:=0.0,pitch_rand:=0.06)->void:
	var path:="res://audio/sfx/"+name+".ogg"
	if not ResourceLoader.exists(path):
		path="res://audio/sfx/%s_%d.ogg"%[name,randi()%3]
	var s:=_load_stream(path)
	if s==null: return
	var p:AudioStreamPlayer=pool[count%pool.size()]; count+=1
	p.stream=s; p.volume_db=vol_db; p.pitch_scale=1.0+randf_range(-pitch_rand,pitch_rand); p.play()

func music(name:String)->void:
	if name==cur_music: return
	cur_music=name
	if name=="": music_player.stop(); return
	var s:AudioStreamOggVorbis=_load_stream("res://audio/music/"+name+".ogg")
	if s: s.loop=true; music_player.stream=s; music_player.play()

func crowd(on:bool)->void:
	if on and not crowd_player.playing:
		var s:AudioStreamOggVorbis=_load_stream("res://audio/sfx/crowd_loop.ogg")
		if s: s.loop=true; crowd_player.stream=s; crowd_player.play()
	elif not on: crowd_player.stop()

func say(id:String,delay:=0.0)->void:
	var s:=_load_stream("res://audio/vo/"+id+".mp3")
	if s==null: return
	if delay>0: await get_tree().create_timer(delay,true,false,true).timeout
	vo_player.stream=s; vo_player.play()
	# duck music under the announcer
	var mi:=AudioServer.get_bus_index("Music"); var base:=linear_to_db(Game.get_setting("Music",.55))
	AudioServer.set_bus_volume_db(mi,base-8.0)
	await get_tree().create_timer(s.get_length()+.1,true,false,true).timeout
	AudioServer.set_bus_volume_db(mi,base)
