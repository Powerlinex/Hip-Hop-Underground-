extends Control
## Settings: bus volumes (Master/Music/SFX/Announcer/Crowd), mute, renderer quality.
func _ready()->void:
	UI.bg(self,.7)
	var v:=UI.vbox(self,12)
	v.add_child(UI.label("SETTINGS",48,Color("#ffd23c")))
	for b in ["Master","Music","SFX","Announcer","Crowd"]:
		var h:=HBoxContainer.new(); h.alignment=BoxContainer.ALIGNMENT_CENTER
		var l:=UI.label(b,20); l.custom_minimum_size=Vector2(160,0); h.add_child(l)
		var s:=HSlider.new(); s.min_value=0; s.max_value=1; s.step=.05; s.custom_minimum_size=Vector2(320,28)
		s.value=Game.get_setting(b,{"Master":.8,"Music":.55,"SFX":.9,"Announcer":1.0,"Crowd":.5}[b])
		s.value_changed.connect(func(x): Game.set_setting(b,x); Sfx.apply_volumes(); if b=="SFX": Sfx.play("punch_light_face"))
		h.add_child(s); v.add_child(h)
	var m:=CheckBox.new(); m.text="Mute all"; m.button_pressed=Game.get_setting("mute",false); m.add_theme_font_size_override("font_size",20)
	m.toggled.connect(func(x): Game.set_setting("mute",x); Sfx.apply_volumes()); v.add_child(UI.center(m))
	var cur:=RenderingServer.get_current_rendering_method()
	v.add_child(UI.label("Renderer now: "+cur+("  (HIGH: SSAO + SSR + soft shadows)" if cur=="forward_plus" else "  (default, best for M1 8 GB)"),16,Color("#c9a7ff")))
	var q:=UI.button("QUALITY: HIGH (Forward+) — applies on restart" if cur!="forward_plus" else "QUALITY: STANDARD (Mobile) — applies on restart",_toggle_quality,Color("#4fb6ff"))
	v.add_child(UI.center(q))
	v.add_child(UI.center(UI.button("BACK",func(): Game.goto("MainMenu"))))
func _toggle_quality()->void:
	# override.cfg next to the executable (or project dir) is read at startup by Godot.
	var want:="mobile" if RenderingServer.get_current_rendering_method()=="forward_plus" else "forward_plus"
	var paths:=[OS.get_executable_path().get_base_dir()+"/override.cfg", ProjectSettings.globalize_path("res://override.cfg"), "user://override.cfg"]
	for p in paths:
		var f:=FileAccess.open(p,FileAccess.WRITE)
		if f:
			f.store_string("[rendering]\nrenderer/rendering_method=\"%s\"\n"%want); f.close(); Game.log_line("wrote "+p)
	OS.alert("Quality switched to %s. Restart the game to apply.\n(Or launch with:  --rendering-method %s)"%[want,want],"Hip Hop Underground")
