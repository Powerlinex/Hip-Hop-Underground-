# Hip Hop Underground — Godot 4.7 edition

2.5D neon street fighter, a port of the HHU web prototype v4 (16 original fighters, story mode, grabs/throws, Modes).

## Open the project in Godot
1. Install **Godot 4.7.x (standard, not .NET)** from https://godotengine.org/download/macos/
2. Unzip `hhu_godot_project.zip`, then in Godot's Project Manager choose **Import** and pick `project.godot`.
   The first open re-imports the models and audio, which takes about a minute.
3. Press **F5** (Play). The main scene is `scenes/MainMenu.tscn`.

The renderer defaults to **Mobile**, which suits a MacBook Air M1 with 8 GB of RAM (uses Metal; has glow and ACES tonemapping).
The Web export uses **Compatibility**. Use **Settings → Quality: HIGH (Forward+)** to turn on SSAO and SSR. It applies after a restart,
or you can launch with `--rendering-method forward_plus`.

## Run the exported Mac app (unsigned)
Unzip `HipHopUnderground_macOS_arm64.zip` and move **Hip Hop Underground.app** to Applications. The app is ad-hoc signed but not notarized, so:
- **Right-click (or Control-click) the app → Open → Open**, or
- double-click it once, then go to **System Settings → Privacy & Security → "Hip Hop Underground was blocked" → Open Anyway**.
- If macOS says the app is "damaged", run `xattr -dr com.apple.quarantine "/Applications/Hip Hop Underground.app"` in Terminal.

## Web build
`export/web/` is a static site (index.html + .wasm + .pck). Serve it over HTTP, e.g. `python3 -m http.server` inside the folder,
or put it on GitHub Pages. This uses the single-threaded build, so no special headers are needed.

## Controls
| Action | P1 keyboard | Gamepad | P2 keyboard |
|---|---|---|---|
| Move | A / D | D-pad / left stick | ← → |
| Jump | W | D-pad up | ↑ |
| Block / crouch (down + attack = low) | S | D-pad down | ↓ |
| Light | J | X / Square | Num1 |
| Heavy (forward+H = haymaker, back+H = uppercut) | K | Y / Triangle | Num2 |
| Grab (then J = strike up to 3, K = throw, back+K = throw backwards; victim mashes to break) | L | B / Circle | Num3 |
| Counter | I | RB | Num5 |
| Mode / Special (full hype bar) | U | LB | Num4 |

Strings: chain Light/Heavy on hit. Each fighter's signature strings are shown on the select screen.

## Testing / automation
- `godot --headless --path . -- --autotest=match [--pick=3,0 --cpuhp=1]` plays a CPU-vs-CPU match, prints `[HHU]` logs, then quits.
- `godot --headless --path . -- --autotest=story` plays a story chapter (cutscene, then fight) and writes the save to `user://save.cfg`.
- `tools/build_anims.gd` rebuilds `anim/fight_lib.res` from `fighters/anims.glb` and `fighters/fight.glb`.

## Layout
`scripts/game.gd` (autoload: data, save, input map), `scripts/sfx.gd` (audio buses and players), `scripts/fight.gd` (arena, sim, AI, HUD, cutscenes),
`scripts/fighter.gd` (CharacterBody3D, AnimationTree, Area3D boxes), `scripts/flinch.gd` (additive SkeletonModifier3D), `scripts/fx.gd` (GPUParticles3D),
`data/game.json` (roster, frame data, strings, throws, seasons; exported from the web build).

Audio: all SFX and music were synthesized by project code and rendered to OGG; the announcer was made with eSpeak NG. See CREDITS.txt.
